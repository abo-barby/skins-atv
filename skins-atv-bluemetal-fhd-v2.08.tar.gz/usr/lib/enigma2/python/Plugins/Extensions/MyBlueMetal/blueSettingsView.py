# Embedded file name: /usr/lib/enigma2/python/Plugins/Extensions/MyBlueMetal/blueSettingsView.py
from . import _
from Screens.Screen import Screen
from Components.ActionMap import ActionMap
from Components.ConfigList import ConfigListScreen
from Components.Sources.StaticText import StaticText
from Components.config import config, getConfigListEntry, ConfigNothing
from .blueSystemSettings import blueSystemSettings
from .blueWeatherConfig import blueWeatherConfig
from .blueOtherSettings import blueOtherSettings
from .blueDarkSkyWeather import blueDarkSkyWeather
from Tools.Directories import resolveFilename, SCOPE_PLUGINS


class blueSettingsView(Screen, ConfigListScreen):
	with open(resolveFilename(SCOPE_PLUGINS, 'Extensions/MyBlueMetal/skin/blueSettingsView.xml'), 'r') as f:
		skin = f.read()

	def __init__(self, session, args = 0):
		Screen.__init__(self, session)
		self.session = session
		self.list = []
		ConfigListScreen.__init__(self, self.list, session=self.session, on_change=self.changedEntry)
		self["titleText"] = StaticText("")
		self["titleText"].setText(_("MyBlueMetal"))
		self["key_red"] = StaticText("")
		self["key_red"].setText(_("Exit"))
		self["key_blue"] = StaticText("")
		self["key_blue"]. setText(_("Weather"))
		self["setupActions"] = ActionMap(["OkCancelActions", "ColorActions"], {
			"ok": self.keyOk,
			"red": self.cancel,
			"blue": self.key_blue,
			"cancel": self.cancel}, -1)
		self.createConfigList()


	def createConfigList(self):
		self.weather = getConfigListEntry(_('Weather settings'), ConfigNothing())
		self.font = getConfigListEntry(_('System Settings'), ConfigNothing())
		self.other = getConfigListEntry(_('Other Settings'), ConfigNothing())
		self.list = []
		self.list.append(self.weather)
		self.list.append(self.font)
		self.list.append(self.other)
		self['config'].list = self.list
		self['config'].l.setList(self.list)

	def keyOk(self):
		sel = self['config'].getCurrent()
		if sel is not None and sel == self.weather:
			self.session.open(blueWeatherConfig)
		elif sel is not None and sel == self.font:
			self.session.open(blueSystemSettings)
		elif sel is not None and sel == self.other:
			self.session.open(blueOtherSettings)
		return

	def key_blue(self):
		self.session.open(blueDarkSkyWeather)


	def cancel(self):
		self.close()
