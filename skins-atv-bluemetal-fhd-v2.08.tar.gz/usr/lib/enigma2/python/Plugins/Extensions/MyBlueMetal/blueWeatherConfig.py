# Embedded file name: /usr/lib/enigma2/python/Plugins/Extensions/MyBlueMetal/blueWeatherConfig.py
from . import _
from enigma import eTimer
from Components.ActionMap import ActionMap
from Components.config import config, getConfigListEntry, ConfigText, ConfigSubsection, ConfigSelection, ConfigYesNo, NoSave, ConfigNothing, ConfigNumber, configfile
from Components.ConfigList import ConfigListScreen
from Components.Label import Label
from Components.Pixmap import Pixmap
from Components.Sources.List import List
from Components.Sources.StaticText import StaticText
from Screens.MessageBox import MessageBox
from Screens.Screen import Screen
from Screens.Standby import TryQuitMainloop
from Tools.LoadPixmap import LoadPixmap
from Tools.Directories import resolveFilename, SCOPE_PLUGINS


config.plugins.blueMetal = ConfigSubsection()
config.plugins.blueMetal.windspeedUnit = ConfigSelection(default='km/h', choices=[('km/h', _(' km/h')), ('m/s', _(' m/s'))])
config.plugins.blueMetal.winddirection = ConfigSelection(default='long', choices=[('long', _('Long')), ('short', _('Short'))])
config.plugins.blueMetal.pressureUnit = ConfigSelection(default='mmHg', choices=[('mmHg', _(' mmHg')), ('mBar', _(' mBar'))])
config.plugins.blueMetal.WeekDay = ConfigSelection(default='dm', choices=[('dm', _('d.m.')), ('dmy', _('d.m.y.'))])

config.plugins.blueMetal.Provider = ConfigSelection(default = 'Darksky', choices =['Darksky', 'OpenWeathermap', 'Weatherbit'])
config.plugins.blueMetal.numbers = ConfigSelection(default = '1', choices=[('0'), ('1'), ('2')])
config.plugins.blueMetal.CountryCode = ConfigSelection(default = "uk", choices = [
	("de", _("German")),
	("en", _("English")),
	("ru", _("Russian")),
	("uk", _("Ukrainian"))
])
config.plugins.blueMetal.Darksky_apikey = ConfigText(default = '1234567890abcdef', visible_width = 40, fixed_size = False)

config.plugins.blueMetal.weather_place = ConfigSelection(default = '1', choices=[('1'), ('2'), ('3')])

config.plugins.blueMetal.namecity1 = ConfigText(default = '', visible_width = 50, fixed_size = False)
config.plugins.blueMetal.Weather_lat1 = ConfigText(default = '1.0000', visible_width = 8, fixed_size = False)
config.plugins.blueMetal.Weather_lon1 = ConfigText(default = '2.0000', visible_width = 8, fixed_size = False)
config.plugins.blueMetal.namecity2 = ConfigText(default = '', visible_width = 50, fixed_size = False)
config.plugins.blueMetal.Weather_lat2 = ConfigText(default = '1.0000', visible_width = 8, fixed_size = False)
config.plugins.blueMetal.Weather_lon2 = ConfigText(default = '2.0000', visible_width = 8, fixed_size = False)
config.plugins.blueMetal.namecity3 = ConfigText(default = '', visible_width = 50, fixed_size = False)
config.plugins.blueMetal.Weather_lat3 = ConfigText(default = '1.0000', visible_width = 8, fixed_size = False)
config.plugins.blueMetal.Weather_lon3 = ConfigText(default = '2.0000', visible_width = 8, fixed_size = False)

config.plugins.blueMetal.OpenWeathermap_apikey = ConfigText(default = '1234567890abcdef', visible_width = 40, fixed_size = False)
config.plugins.blueMetal.Open_city1 = ConfigText(default = '', visible_width = 50, fixed_size = False)
config.plugins.blueMetal.OpenWeathermap_idcity1 = ConfigText(default = '1234567', visible_width = 10, fixed_size = False)
config.plugins.blueMetal.Open_city2 = ConfigText(default = '', visible_width = 50, fixed_size = False)
config.plugins.blueMetal.OpenWeathermap_idcity2 = ConfigText(default = '1234567', visible_width = 10, fixed_size = False)
config.plugins.blueMetal.Open_city3 = ConfigText(default = '', visible_width = 50, fixed_size = False)
config.plugins.blueMetal.OpenWeathermap_idcity3 = ConfigText(default = '1234567', visible_width = 10, fixed_size = False)

config.plugins.blueMetal.Weatherbit_apikey = ConfigText(default = '1234567890abcdef', visible_width = 40, fixed_size = False)
config.plugins.blueMetal.namecity1 = ConfigText(default = '', visible_width = 50, fixed_size = False)
config.plugins.blueMetal.Weather_lat1 = ConfigText(default = '1.0000', visible_width = 8, fixed_size = False)
config.plugins.blueMetal.Weather_lon1 = ConfigText(default = '2.0000', visible_width = 8, fixed_size = False)
config.plugins.blueMetal.namecity2 = ConfigText(default = '', visible_width = 50, fixed_size = False)
config.plugins.blueMetal.Weather_lat2 = ConfigText(default = '1.0000', visible_width = 8, fixed_size = False)
config.plugins.blueMetal.Weather_lon2 = ConfigText(default = '2.0000', visible_width = 8, fixed_size = False)
config.plugins.blueMetal.namecity3 = ConfigText(default = '', visible_width = 50, fixed_size = False)
config.plugins.blueMetal.Weather_lat3 = ConfigText(default = '1.0000', visible_width = 8, fixed_size = False)
config.plugins.blueMetal.Weather_lon3 = ConfigText(default = '2.0000', visible_width = 8, fixed_size = False)

config.plugins.blueMetal.animatedWeather = ConfigSelection(default='static', choices=[('static', _('Static')), ('animated', _('Animated'))])
config.plugins.blueMetal.StartScreen = ConfigSelection(default = "cfg", choices = [("cfg", _("Setup")),	("cst", _("Weather"))])


class blueWeatherConfig(Screen, ConfigListScreen):
	with open(resolveFilename(SCOPE_PLUGINS, 'Extensions/MyBlueMetal/skin/blueWeatherConfig.xml'), 'r') as f:
		skin = f.read()

	def __init__(self, session, args = 0):
		self.session = session
		self.skin_lines = []
		self.changed_screens = False
		Screen.__init__(self, session)
		self.list = []
		ConfigListScreen.__init__(self, self.list, session=self.session, on_change=self.changedEntry)
		self.setTitle(_('blueWeather Config'))
		self['key_red'] = Label(_('Cancel'))
		self['key_green'] = Label(_('OK'))
		self['setupActions'] = ActionMap(['DirectionActions', 'SetupActions', 'ColorActions'], {'green': self.save,
		 'left': self.keyLeft,
		 'right': self.keyRight,
		 'ok': self.save,  
		 'red': self.cancel,
		 'cancel': self.cancel}, -2)
		self.timer = eTimer()
		self.timer.callback.append(self.createConfigList)
		self.onLayoutFinish.append(self.createConfigList)
		self['HelpWindow'] = Pixmap()

	def createConfigList(self):
		tab = '     '
		self.list = []
		self.list.append(getConfigListEntry(_('Windspeed unit'), config.plugins.blueMetal.windspeedUnit))
		self.list.append(getConfigListEntry(_('Wind Direction'), config.plugins.blueMetal.winddirection))
		self.list.append(getConfigListEntry(_('Pressure unit'), config.plugins.blueMetal.pressureUnit))
		self.list.append(getConfigListEntry(_('Weekday format'), config.plugins.blueMetal.WeekDay))
		self.list.append(getConfigListEntry(_("StartScreen"), config.plugins.blueMetal.StartScreen))

		self.list.append(getConfigListEntry(_('Weather Picon'), config.plugins.blueMetal.animatedWeather))

		self.list.append(getConfigListEntry(_('Provider'), config.plugins.blueMetal.Provider))
		if config.plugins.blueMetal.Provider.value == 'Darksky':
			self.list.append(getConfigListEntry(tab + _('Number of decimal places'), config.plugins.blueMetal.numbers))
			self.list.append(getConfigListEntry(tab + _('Darksky API-Key'), config.plugins.blueMetal.Darksky_apikey))
			self.list.append(getConfigListEntry(tab + _('City'), config.plugins.blueMetal.weather_place))
			if config.plugins.blueMetal.weather_place.value == '1':
				self.list.append(getConfigListEntry(tab + tab + _('Name City'), config.plugins.blueMetal.namecity1))
				self.list.append(getConfigListEntry(tab + tab + _('Latitude'), config.plugins.blueMetal.Weather_lat1))
				self.list.append(getConfigListEntry(tab + tab + _('Longitude'), config.plugins.blueMetal.Weather_lon1))
			if config.plugins.blueMetal.weather_place.value == '2':
				self.list.append(getConfigListEntry(tab + tab + _('Name City'), config.plugins.blueMetal.namecity2))
				self.list.append(getConfigListEntry(tab + tab + _('Latitude'), config.plugins.blueMetal.Weather_lat2))
				self.list.append(getConfigListEntry(tab + tab + _('Longitude'), config.plugins.blueMetal.Weather_lon2))
			if config.plugins.blueMetal.weather_place.value == '3':
				self.list.append(getConfigListEntry(tab + tab + _('Name City'), config.plugins.blueMetal.namecity3))
				self.list.append(getConfigListEntry(tab + tab + _('Latitude'), config.plugins.blueMetal.Weather_lat3))
				self.list.append(getConfigListEntry(tab + tab + _('Longitude'), config.plugins.blueMetal.Weather_lon3))

		if config.plugins.blueMetal.Provider.value == 'Weatherbit':
			self.list.append(getConfigListEntry(tab + _('Number of decimal places'), config.plugins.blueMetal.numbers))
			self.list.append(getConfigListEntry(tab + _('Weatherbit API-Key'), config.plugins.blueMetal.Weatherbit_apikey))
			self.list.append(getConfigListEntry(tab + _('City'), config.plugins.blueMetal.weather_place))
			if config.plugins.blueMetal.weather_place.value == '1':
				self.list.append(getConfigListEntry(tab + tab + _('Name City'), config.plugins.blueMetal.namecity1))
				self.list.append(getConfigListEntry(tab + tab + _('Latitude'), config.plugins.blueMetal.Weather_lat1))
				self.list.append(getConfigListEntry(tab + tab + _('Longitude'), config.plugins.blueMetal.Weather_lon1))
			if config.plugins.blueMetal.weather_place.value == '2':
				self.list.append(getConfigListEntry(tab + tab + _('Name City'), config.plugins.blueMetal.namecity2))
				self.list.append(getConfigListEntry(tab + tab + _('Latitude'), config.plugins.blueMetal.Weather_lat2))
				self.list.append(getConfigListEntry(tab + tab + _('Longitude'), config.plugins.blueMetal.Weather_lon2))
			if config.plugins.blueMetal.weather_place.value == '3':
				self.list.append(getConfigListEntry(tab + tab + _('Name City'), config.plugins.blueMetal.namecity3))
				self.list.append(getConfigListEntry(tab + tab + _('Latitude'), config.plugins.blueMetal.Weather_lat3))
				self.list.append(getConfigListEntry(tab + tab + _('Longitude'), config.plugins.blueMetal.Weather_lon3))

		if config.plugins.blueMetal.Provider.value == 'OpenWeathermap':
			self.list.append(getConfigListEntry(tab + _('OpenWeathermap API-Key'), config.plugins.blueMetal.OpenWeathermap_apikey))
			self.list.append(getConfigListEntry(tab + _('City'), config.plugins.blueMetal.weather_place))
			if config.plugins.blueMetal.weather_place.value == '1':
				self.list.append(getConfigListEntry(tab + tab + _('Name City'), config.plugins.blueMetal.Open_city1))
				self.list.append(getConfigListEntry(tab + tab + _('OpenWeathermap ID City'), config.plugins.blueMetal.OpenWeathermap_idcity1))
			if config.plugins.blueMetal.weather_place.value == '2':
				self.list.append(getConfigListEntry(tab + tab + _('Name City'), config.plugins.blueMetal.Open_city2))
				self.list.append(getConfigListEntry(tab + tab + _('OpenWeathermap ID City'), config.plugins.blueMetal.OpenWeathermap_idcity2))
			if config.plugins.blueMetal.weather_place.value == '3':
				self.list.append(getConfigListEntry(tab + tab + _('Name City'), config.plugins.blueMetal.Open_city3))
				self.list.append(getConfigListEntry(tab + tab + _('OpenWeathermap ID City'), config.plugins.blueMetal.OpenWeathermap_idcity3))

		self.list.append(getConfigListEntry(_('Language (weather descriptions)'), config.plugins.blueMetal.CountryCode))

		self['config'].list = self.list
		self['config'].l.setList(self.list)

	def keyLeft(self):
		ConfigListScreen.keyLeft(self)
		self.mylist()

	def keyRight(self):
		ConfigListScreen.keyRight(self)
		self.mylist()

	def mylist(self):
		self.timer.start(100, True)

	def cancel(self):
		for x in self['config'].list:
			if len(x) > 1:
				x[1].cancel()
			else:
				pass
		self.close(self.session, True)

	def save(self):
		for x in self['config'].list:
			if len(x) > 1:
				x[1].save()
			else:
				pass
		configfile.save()
		restartbox = self.session.openWithCallback(self.restartGUI,MessageBox,_("Restart necessary, restart GUI now?"), MessageBox.TYPE_YESNO)
		restartbox.setTitle(_("Question"))

	def restartGUI(self, answer):
		if answer is True:
			configfile.save()
			self.session.open(TryQuitMainloop, 3)
