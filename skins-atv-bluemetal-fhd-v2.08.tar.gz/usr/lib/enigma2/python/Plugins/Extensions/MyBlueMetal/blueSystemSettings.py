# Embedded file name: /usr/lib/enigma2/python/Plugins/Extensions/MyBlueMetal/blueSystemSettings.py
from . import _
from Screens.Screen import Screen
from Screens.MessageBox import MessageBox
from Screens.Standby import TryQuitMainloop
from Components.Sources.StaticText import StaticText
from Components.ActionMap import ActionMap
from Components.AVSwitch import AVSwitch
from Components.config import config, configfile, ConfigYesNo, ConfigSubsection, getConfigListEntry, ConfigSelection, ConfigNumber, ConfigText, ConfigInteger
from Components.ConfigList import ConfigListScreen
from Components.Label import Label
from Components.Pixmap import Pixmap
from enigma import ePicLoad, eTimer
from Tools.Directories import SCOPE_CURRENT_SKIN, fileExists, resolveFilename, SCOPE_LANGUAGE, SCOPE_PLUGINS


class blueSystemSettings(ConfigListScreen, Screen):
	with open(resolveFilename(SCOPE_PLUGINS, 'Extensions/MyBlueMetal/skin/blueSystemSettings.xml'), 'r') as f:
		skin = f.read()

	def __init__(self, session, args = None, picPath = None):
		self.skin_lines = []
		Screen.__init__(self, session)
		self.session = session
		self.datei = "/usr/share/enigma2/BlueMetalFHD/skin.xml"
		self.daten = "/usr/lib/enigma2/python/Plugins/Extensions/MyBlueMetal/data/"
		self.picPath = picPath
		self.Scale = AVSwitch().getFramebufferScale()
		self.PicLoad = ePicLoad()
		self["helperimage"] = Pixmap()
		list = []
		ConfigListScreen.__init__(self, list)
		self.onLayoutFinish.append(self.layoutFinished)
		self["key_red"] = StaticText("")
		self["key_red"].setText(_("Cancel"))
		self["key_green"] = StaticText("")
		self["key_green"].setText(_("Save"))
		self["actions"] = ActionMap(["OkCancelActions",
			"DirectionActions",
			"InputActions",
			"MenuActions",
			"NumberActions",
			"ColorActions"], {"red": self.exit,
		"left": self.keyLeft,
		"down": self.keyDown,
		"up": self.keyUp,
		"right": self.keyRight,
		"green": self.save,
		"cancel": self.exit,}, -1)
		self.UpdatePicture()
		self.timer = eTimer()
		spath=resolveFilename(SCOPE_CURRENT_SKIN) + "skin.xml"
		self.aktiv=None
		if "BlueMetalFHD" in str(spath):
                    self.aktiv=1
		self.timer.callback.append(self.updateMylist)
		self.onLayoutFinish.append(self.updateMylist)

	def keyLeft(self):
		ConfigListScreen.keyLeft(self)
		self.mylist()

	def keyRight(self):
		ConfigListScreen.keyRight(self)
		self.mylist()

	def keyDown(self):
		self["config"].instance.moveSelection(self["config"].instance.moveDown)
		self.mylist()

	def keyUp(self):
		self["config"].instance.moveSelection(self["config"].instance.moveUp)
		self.mylist()
	
	
	def save(self):
		for x in self["config"].list:
			if len(x) > 1:
					x[1].save()
			else:
					pass
		if True:
			self.skinSearchAndReplace = []

			if config.blueSystemSetup.ScrolBarColor.value == "#00ffffff":
				self.skinSearchAndReplace.append(['#color2', '#00ffffff'])
			elif config.blueSystemSetup.ScrolBarColor.value == "#00ffd200":
				self.skinSearchAndReplace.append(['#color2', '#00ffd200'])
			elif config.blueSystemSetup.ScrolBarColor.value == "#0038b901":
				self.skinSearchAndReplace.append(['#color2', '#0038b901'])
			elif config.blueSystemSetup.ScrolBarColor.value == "#00f50404":
				self.skinSearchAndReplace.append(['#color2', '#00f50404'])

			if config.blueSystemSetup.ChFont.value == "regular":
				self.skinSearchAndReplace.append(['NameFont.ttf', 'Cuprum_Regular.ttf'])
			elif config.blueSystemSetup.ChFont.value == "italic":
				self.skinSearchAndReplace.append(['NameFont.ttf', 'Cuprum_Italic.ttf'])
			elif config.blueSystemSetup.ChFont.value == "bold":
				self.skinSearchAndReplace.append(['NameFont.ttf', 'Cuprum_Bold.ttf'])
			elif config.blueSystemSetup.ChFont.value == "bolditalic":
				self.skinSearchAndReplace.append(['NameFont.ttf', 'Cuprum_Bold_Italic.ttf'])

			if config.blueSystemSetup.infoFont.value == "regular":
				self.skinSearchAndReplace.append(['InfoFont.ttf', 'Cuprum_Regular.ttf'])
			elif config.blueSystemSetup.infoFont.value == "italic":
				self.skinSearchAndReplace.append(['InfoFont.ttf', 'Cuprum_Italic.ttf'])
			elif config.blueSystemSetup.infoFont.value == "bold":
				self.skinSearchAndReplace.append(['InfoFont.ttf', 'Cuprum_Bold.ttf'])
			elif config.blueSystemSetup.infoFont.value == "bolditalic":
				self.skinSearchAndReplace.append(['InfoFont.ttf', 'Cuprum_Bold_Italic.ttf'])

			if config.blueSystemSetup.Font.value == "regular":
				self.skinSearchAndReplace.append(['systFont.ttf', 'Cuprum_Regular.ttf'])
			elif config.blueSystemSetup.Font.value == "italic":
				self.skinSearchAndReplace.append(['systFont.ttf', 'Cuprum_Italic.ttf'])
			elif config.blueSystemSetup.Font.value == "bold":
				self.skinSearchAndReplace.append(['systFont.ttf', 'Cuprum_Bold.ttf'])
			elif config.blueSystemSetup.Font.value == "bolditalic":
				self.skinSearchAndReplace.append(['systFont.ttf', 'Cuprum_Bold_Italic.ttf'])

			if config.blueSystemSetup.ChanNameFont.value == "regular":
				self.skinSearchAndReplace.append(['chan_name.ttf', 'Cuprum_Regular.ttf'])
			elif config.blueSystemSetup.ChanNameFont.value == "italic":
				self.skinSearchAndReplace.append(['chan_name.ttf', 'Cuprum_Italic.ttf'])
			elif config.blueSystemSetup.ChanNameFont.value == "bold":
				self.skinSearchAndReplace.append(['chan_name.ttf', 'Cuprum_Bold.ttf'])
			elif config.blueSystemSetup.ChanNameFont.value == "bolditalic":
				self.skinSearchAndReplace.append(['chan_name.ttf', 'Cuprum_Bold_Italic.ttf'])

		try:
			self.appendSkinFile(self.daten + "header.xml")
			self.appendSkinFile(self.daten + "end.xml")

			with open(self.datei, "w") as _f:
				for l in self.skin_lines:
					_f.writelines(l)
		except:
			self.session.open(MessageBox, _("Error creating Skin!"), MessageBox.TYPE_ERROR)
		configfile.save()
		restartbox = self.session.openWithCallback(self.restartGUI,MessageBox,_("Restart necessary, restart GUI now?"), MessageBox.TYPE_YESNO)
		restartbox.setTitle(_("Question"))


	def restartGUI(self, answer):
		if answer is True:
			configfile.save()
			self.session.open(TryQuitMainloop, 3)
	
	def appendSkinFile(self, appendFileName, skinPartSearchAndReplace=None):
		with open(appendFileName, "r") as skFile:
			file_lines = skFile.readlines()

		tmpSearchAndReplace = []

		if skinPartSearchAndReplace is not None:
			tmpSearchAndReplace = self.skinSearchAndReplace + skinPartSearchAndReplace
		else:
			tmpSearchAndReplace = self.skinSearchAndReplace

		for skinLine in file_lines:
			for item in tmpSearchAndReplace:
				skinLine = skinLine.replace(item[0], item[1])
			self.skin_lines.append(skinLine)

	def exit(self):
		for x in self["config"].list:
			if len(x) > 1:
					x[1].cancel()
			else:
       				pass
		self.close(self.session, True)

	
	def layoutFinished(self):
		self.setTitle(_("blueSystem Settings"))
	
	def mylist(self):
		self.timer.start(100, True)
		
	def updateMylist(self):	
		tab = "          "
		list = []
		list.append(getConfigListEntry(tab + _("Font"),))
		list.append(getConfigListEntry(_("System Font"), config.blueSystemSetup.Font))
		list.append(getConfigListEntry(_("Channel List Font"), config.blueSystemSetup.ChFont))
		list.append(getConfigListEntry(_("Channel Info Font"), config.blueSystemSetup.infoFont))
		list.append(getConfigListEntry(_("Channel Name Font"), config.blueSystemSetup.ChanNameFont))

		list.append(getConfigListEntry(tab + _("Color"),))
		list.append(getConfigListEntry(_("Scrol Bar Color"), config.blueSystemSetup.ScrolBarColor))

		self["helperimage"].show()
		self.ShowPicture()
		self["config"].list = list
		self["config"].l.setList(list)

	def GetPicturePath(self):
		try:
			returnValue = self["config"].getCurrent()[1].value
			path = "/usr/lib/enigma2/python/Plugins/Extensions/MyBlueMetal/images/" + returnValue + ".png"
			if fileExists(path):
				return path
		except:
			return "/usr/lib/enigma2/python/Plugins/Extensions/MyBlueMetal/images/True.png"
	
	def UpdatePicture(self):
		self.PicLoad.PictureData.get().append(self.DecodePicture)
		self.onLayoutFinish.append(self.ShowPicture)

	def ShowPicture(self):
		self.PicLoad.setPara([self["helperimage"].instance.size().width(),self["helperimage"].instance.size().height(),self.Scale[0],self.Scale[1],0,1,"#00000000"])
		if self.picPath is not None:
			self.PicLoad.startDecode(self.picPath)
			self.picPath = None
		else:
			self.PicLoad.startDecode(self.GetPicturePath())

	def DecodePicture(self, PicInfo = ""):
		ptr = self.PicLoad.getData()
		self["helperimage"].instance.setPixmap(ptr)
	
	
config.blueSystemSetup = ConfigSubsection()

config.blueSystemSetup.ChanNameFont = ConfigSelection(default="regular", choices = [
				("regular", _("Regular")),
				("italic", _("Italic Font")),
				("bold", _("Bold Font")),
				("bolditalic", _("Bold Italic Font"))
				])

config.blueSystemSetup.Font = ConfigSelection(default="regular", choices = [
				("regular", _("Regular")),
				("italic", _("Italic Font")),
				("bold", _("Bold Font")),
				("bolditalic", _("Bold Italic Font"))
				])

config.blueSystemSetup.ChFont = ConfigSelection(default="regular", choices = [
				("regular", _("Regular")),
				("italic", _("Italic Font")),
				("bold", _("Bold Font")),
				("bolditalic", _("Bold Italic Font"))
				])

config.blueSystemSetup.infoFont = ConfigSelection(default="regular", choices = [
				("regular", _("Regular")),
				("italic", _("Italic Font")),
				("bold", _("Bold Font")),
				("bolditalic", _("Bold Italic Font"))
				])

config.blueSystemSetup.ScrolBarColor = ConfigSelection(default="#00ffffff", choices = [
				("#00ffffff", _("White")),
				("#00ffd200", _("Yellow")),
				("#0038b901", _("Green")),
				("#00f50404", _("Red"))
				])
