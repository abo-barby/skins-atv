# Embedded file name: /usr/lib/enigma2/python/Plugins/Extensions/MyBlueMetal/blueOtherSettings.py
from . import _
from Screens.Screen import Screen
from Screens.MessageBox import MessageBox
from Screens.Standby import TryQuitMainloop
from Components.Sources.StaticText import StaticText
from Components.ActionMap import ActionMap
from Components.AVSwitch import AVSwitch
from Components.config import config, configfile, ConfigYesNo, ConfigSubsection, getConfigListEntry, ConfigSelection, ConfigNumber, ConfigText, ConfigInteger, ConfigNothing
from Components.ConfigList import ConfigListScreen
from Components.Label import Label
from enigma import ePicLoad, eTimer
from Components.Pixmap import Pixmap
from Tools.Directories import SCOPE_CURRENT_SKIN, fileExists, resolveFilename, SCOPE_LANGUAGE, SCOPE_PLUGINS

class blueOtherSettings(ConfigListScreen, Screen):
	with open(resolveFilename(SCOPE_PLUGINS, 'Extensions/MyBlueMetal/skin/blueOtherSettings.xml'), 'r') as f:
		skin = f.read()

	def __init__(self, session, args = None, picPath = None):
		self.skin_lines = []
		Screen.__init__(self, session)
		self.session = session
		self.datei = "/usr/share/enigma2/BlueMetalFHD/skins/skin_design.xml"
		self.daten = "/usr/lib/enigma2/python/Plugins/Extensions/MyBlueMetal/data/"
		self.picPath = picPath
		self.Scale = AVSwitch().getFramebufferScale()
		self.PicLoad = ePicLoad()
		self["helperimage"] = Pixmap()
		self['HelpWindow'] = Pixmap()
		list = []
		ConfigListScreen.__init__(self, list, session=self.session, on_change=self.changedEntry)
		self.onLayoutFinish.append(self.layoutFinished)

		self["key_red"] = StaticText("")
		self["key_red"].setText(_("Cancel"))
		self["key_green"] = StaticText("")
		self["key_green"].setText(_("Save"))
		self["actions"] = ActionMap(["OkCancelActions",
		  "DirectionActions",
		  "InputActions",
		  "MenuActions",
		  "NumberActions",
		  "ColorActions"], {"red": self.exit,
		  "left": self.keyLeft,
		  "down": self.keyDown,
		  "up": self.keyUp,
		  "right": self.keyRight,
		  "green": self.save,
		  "ok": self.save,
		  "cancel": self.exit}, -1)
		self.UpdatePicture()
		self.timer = eTimer()
		spath = resolveFilename(SCOPE_CURRENT_SKIN) + "skin_design.xml"
		self.aktiv = None
		if "BlueMetalFHD" in str(spath):
			self.aktiv = 1
		self.timer.callback.append(self.updateMylist)
		self.onLayoutFinish.append(self.updateMylist)

	def keyLeft(self):
		ConfigListScreen.keyLeft(self)
		self.mylist()

	def keyRight(self):
		ConfigListScreen.keyRight(self)
		self.mylist()

	def keyDown(self):
		self["config"].instance.moveSelection(self["config"].instance.moveDown)
		self.mylist()

	def keyUp(self):
		self["config"].instance.moveSelection(self["config"].instance.moveUp)
		self.mylist()
	
	def save(self):
		for x in self["config"].list:
			if len(x) > 1:
					x[1].save()
			else:
					pass
			
		if True:
			self.skinSearchAndReplace = []

			if config.plugins.blueOtherSettings.SecondInfobarTemp.value == True:
				self.skinSearchAndReplace.append(['INFOTEMP_off"', 'INFOTEMP"'])

			if config.plugins.blueOtherSettings.InfobarTuner.value == "tuner_X":
				self.skinSearchAndReplace.append(['INFOBARTUNERINFO-4"', 'INFOBARTUNERINFO-X"'])

			if config.plugins.blueOtherSettings.InfobarClock.value == "analog":
				self.skinSearchAndReplace.append(['Clock_Digital"', 'Clock_Analog"'])
			elif config.plugins.blueOtherSettings.InfobarClock.value == "lcd":
				self.skinSearchAndReplace.append(['Clock_Digital"', 'Clock_Lcd"'])
			elif config.plugins.blueOtherSettings.InfobarClock.value == "flip":
				self.skinSearchAndReplace.append(['Clock_Digital"', 'Clock_Flip"'])

			if config.plugins.blueOtherSettings.InfobarPicon.value == "picanim":
				self.skinSearchAndReplace.append(['InfoBar_Picon_Stat"', 'InfoBar_Picon_Anim"'])

			if config.plugins.blueOtherSettings.MainMenu.value == "mainmenuextra":
				self.skinSearchAndReplace.append(['MENU_template"', 'MENU_template_extra"'])

			if config.plugins.blueOtherSettings.InfobarEvent.value == "eventrun":
				self.skinSearchAndReplace.append(['movetype=none', 'movetype=running'])
			if config.plugins.blueOtherSettings.InfobarWeather.value == True:
				self.skinSearchAndReplace.append(['INFOBARWEATHER_none"', 'INFOBARWEATHER_design"'])

			if config.plugins.blueOtherSettings.InfobarPoster.value == True:
				self.skinSearchAndReplace.append(['InfobarPoster_none"', 'InfobarPoster_design"'])

			if config.plugins.blueOtherSettings.SecondInfobarPoster.value == True:
				self.skinSearchAndReplace.append(['SecondInfobarPoster_off"', 'SecondInfobarPoster"'])
				self.skinSearchAndReplace.append(['860', '660'])

			if config.plugins.blueOtherSettings.ChSelectionBackdrop.value == True:
				self.skinSearchAndReplace.append(['ChSelection_Backdrop_off"', 'ChSelection_Backdrop"'])
				self.skinSearchAndReplace.append(['350', '180'])
		try:
			self.appendSkinFile(self.daten + "design_header.xml")
			self.appendSkinFile(self.daten + "end.xml")

			with open(self.datei, "w") as _f:
				for l in self.skin_lines:
					_f.writelines(l)
		except:
			self.session.open(MessageBox, _("Error creating Skin!"), MessageBox.TYPE_ERROR)
		configfile.save()
		restartbox = self.session.openWithCallback(self.restartGUI,MessageBox,_("Restart necessary, restart GUI now?"), MessageBox.TYPE_YESNO)
		restartbox.setTitle(_("Question"))

	def restartGUI(self, answer):
		if answer is True:
			configfile.save()
			self.session.open(TryQuitMainloop, 3)

	def appendSkinFile(self, appendFileName, skinPartSearchAndReplace = None):
		with open(appendFileName, "r") as skFile:
			file_lines = skFile.readlines()
		tmpSearchAndReplace = []
		if skinPartSearchAndReplace is not None:
			tmpSearchAndReplace = self.skinSearchAndReplace + skinPartSearchAndReplace
		else:
			tmpSearchAndReplace = self.skinSearchAndReplace
		for skinLine in file_lines:
			for item in tmpSearchAndReplace:
				skinLine = skinLine.replace(item[0], item[1])

			self.skin_lines.append(skinLine)

	def exit(self):
		for x in self["config"].list:
			if len(x) > 1:
					x[1].cancel()
			else:
       				pass
		self.close(self.session, True)

	def layoutFinished(self):
		self.setTitle(_("blueOther Settings"))

	def mylist(self):
		self.timer.start(100, True)

	def updateMylist(self):
		tab = '\t'
		list = []
		list.append(getConfigListEntry('{}'.format(2*tab) + _('Infobar'),))
		list.append(getConfigListEntry(_("Event Name & Program Info"), config.plugins.blueOtherSettings.InfobarEvent))
		list.append(getConfigListEntry(_("Tuner Info"), config.plugins.blueOtherSettings.InfobarTuner))
		list.append(getConfigListEntry(_("Clock"), config.plugins.blueOtherSettings.InfobarClock))
		list.append(getConfigListEntry(_("Picon"), config.plugins.blueOtherSettings.InfobarPicon))
		list.append(getConfigListEntry(_("Weather"), config.plugins.blueOtherSettings.InfobarWeather))
		list.append(getConfigListEntry(_('Poster'), config.plugins.blueOtherSettings.InfobarPoster))

		list.append(getConfigListEntry('{}'.format(2*tab) + _('SecondInfobar'),))
		list.append(getConfigListEntry(_("Temperature Info"), config.plugins.blueOtherSettings.SecondInfobarTemp))
		list.append(getConfigListEntry(_("Poster"), config.plugins.blueOtherSettings.SecondInfobarPoster))

		list.append(getConfigListEntry('{}'.format(2*tab) + _("Other"),))
		list.append(getConfigListEntry(_("Main Menu"), config.plugins.blueOtherSettings.MainMenu))

		list.append(getConfigListEntry(_("Backdrop in  Channel  Selection"), config.plugins.blueOtherSettings.ChSelectionBackdrop))

		list.append(getConfigListEntry(_("Enter Tmbd-API-Key"), config.plugins.blueOtherSettings.TmbdKey))
		if config.plugins.blueOtherSettings.TmbdKey.value == True:
			list.append(getConfigListEntry((" "), config.plugins.blueOtherSettings.ApiTmbd))

		self["helperimage"].show()
		self.ShowPicture()
		self["config"].list = list
		self["config"].l.setList(list)


	def GetPicturePath(self):
		try:
			returnValue = self["config"].getCurrent()[1].value
			path = "/usr/lib/enigma2/python/Plugins/Extensions/MyBlueMetal/images/" + returnValue + ".png"

			if fileExists(path):
				return path
		except:
			return "/usr/lib/enigma2/python/Plugins/Extensions/MyBlueMetal/images/True.png"

	def UpdatePicture(self):
		self.PicLoad.PictureData.get().append(self.DecodePicture)
		self.onLayoutFinish.append(self.ShowPicture)

	def ShowPicture(self):
		self.PicLoad.setPara([self["helperimage"].instance.size().width(),self["helperimage"].instance.size().height(),self.Scale[0],self.Scale[1],0,1,"#00000000"])
		if self.picPath is not None:
			self.PicLoad.startDecode(self.picPath)
			self.picPath = None
		else:
			self.PicLoad.startDecode(self.GetPicturePath())

	def DecodePicture(self, PicInfo = ""):
		ptr = self.PicLoad.getData()
		self["helperimage"].instance.setPixmap(ptr)


config.plugins.blueOtherSettings = ConfigSubsection()
#InfobarEventName
config.plugins.blueOtherSettings.InfobarEvent = ConfigSelection(default="eventstat", choices = [
				("eventstat", _("Static")),
				("eventrun", _('Running Text'))
				])
#Tunerinfo
config.plugins.blueOtherSettings.InfobarTuner = ConfigSelection(default="tuner_4", choices = [
				("tuner_4", _("Tuner-4")),
				("tuner_X", _("Tuner-X"))
				])
#InfobarClock
config.plugins.blueOtherSettings.InfobarClock = ConfigSelection(default="digital", choices = [
				("digital", _("Digital")),
				("analog", _("Analog")),
				("lcd", _("LCD")),
				("flip", _("Flip"))
				])
#InfobarPicon
config.plugins.blueOtherSettings.InfobarPicon = ConfigSelection(default="picstat", choices = [
				("picstat", _("Static")),
				("picanim", _("Animated"))
				])
#InfobarWeather
config.plugins.blueOtherSettings.InfobarWeather = ConfigYesNo(default = False)

#InfobarPoster
config.plugins.blueOtherSettings.InfobarPoster = ConfigYesNo(default = False)

#Tempinfo
config.plugins.blueOtherSettings.SecondInfobarTemp = ConfigYesNo(default = False)

#Second Infobar Poster
config.plugins.blueOtherSettings.SecondInfobarPoster = ConfigYesNo(default = False)

#MainMenu
config.plugins.blueOtherSettings.MainMenu = ConfigSelection(default="mainmenu", choices = [
				("mainmenu", _("Standart")),
				("mainmenuextra", _("Extra"))
				])

#Channel Selection Backdrop
config.plugins.blueOtherSettings.ChSelectionBackdrop = ConfigYesNo(default = False)

#Tmbd-API-Enter
config.plugins.blueOtherSettings.TmbdKey = ConfigYesNo(default = False)

#API-TMBD
config.plugins.blueOtherSettings.ApiTmbd = ConfigText(default = '3c3efcf47c3577558812bb9d64019d65', visible_width = 36, fixed_size = False)