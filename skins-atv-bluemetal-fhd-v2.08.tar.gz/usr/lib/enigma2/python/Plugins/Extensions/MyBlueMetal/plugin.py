# BlueMetalFHD
# -*- coding: utf-8 -*-
from . import _
from Plugins.Plugin import PluginDescriptor
from Components.config import config
from .blueSettingsView import blueSettingsView
from .blueDarkSkyWeather import blueDarkSkyWeather

start_screen = config.plugins.blueMetal.StartScreen.value

def main(session, **kwargs):
	if start_screen == "cfg":
		session.open(blueSettingsView)
	elif start_screen == "cst":
		session.open(blueDarkSkyWeather)
	else:
		session.open(blueSettingsView)

def Plugins(**kwargs):
	return PluginDescriptor(name="MyBlueMetal", description=_("Configuration tool for BlueMetalFHD"), where=PluginDescriptor.WHERE_PLUGINMENU, icon="plugin.png", fnc=main)