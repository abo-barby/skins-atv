# -*- coding: utf-8 -*-
# by digiteng...03.2020
# file for skin BlueMetalFHD

from Components.Renderer.Renderer import Renderer
from enigma import ePixmap, ePicLoad, eTimer, gPixmapPtr
from Components.AVSwitch import AVSwitch
from Components.Pixmap import Pixmap
from Components.config import config
from collections import OrderedDict
from time import gmtime

try:
	import simplejson as json
except ImportError:
	import json

import re, os, sys, zlib, socket, ssl, tempfile

PY3 = (sys.version_info[0] == 3)

if PY3:
	from urllib.request import urlopen, Request
	from urllib.parse import quote, urlencode
else:
	from urllib import quote, urlencode
	from urllib2 import urlopen, Request

temp_dir = tempfile.gettempdir()
timeout = int(config.usage.infobar_timeout.index)
tmdb_api = config.plugins.blueOtherSettings.ApiTmbd.value
context = ssl._create_unverified_context()

REGEX = re.compile(
		r'[0-9]+\+|'
		r'([\(\[]).*?([\)\]])|'
		r'\d{1,3}\:\sodc|'
		r'\:\sodc|'
		r'\d{1,3}\s\(odc|'
		r'\s\(odc|'
		r'(x|X|х|Х|м|М)/ф|'
		r'(т|Т)/с|'
		r'\d{1,3}-я\sсерия|'
		r'(\s\-(.*?).*)|'
		r'[\^\{\}\$\\/\*"<\:>,-\.\|]', re.DOTALL)

HEADERS = {
	'User-Agent': 'Magic Browser',
	'Accept-encoding': 'gzip, deflate',
	'Connection': 'close',
	}

getRespData = lambda resp: {
			'deflate': lambda: zlib.decompress(resp.read(), -zlib.MAX_WBITS),
			'gzip'   : lambda: zlib.decompress(resp.read(), zlib.MAX_WBITS|16),
			}.get(resp.info().get('Content-Encoding'), lambda: resp.read())()


class bluePoster(Renderer):
	def __init__(self):
		Renderer.__init__(self)
		self.evntNm = self.poster_file = None
		self.cache = OrderedDict() # FIFO posters ZapHistory


	def intCheck(self):
		try:
			socket.setdefaulttimeout(0.5)
			socket.socket(socket.AF_INET, socket.SOCK_STREAM).connect(("8.8.8.8", 53))
			return True
		except:
			return False


	GUI_WIDGET = ePixmap

	def changed(self, what):
		if not self.instance:
			return
		else:
			if what[0] != self.CHANGED_CLEAR:
				self.delay()

	def showPoster(self):
		self.instance.setPixmap(gPixmapPtr())
		self.event = self.source.event
		if self.event is None:
			return

		self.evntNm = REGEX.sub('', self.event.getEventName().split('.')[0]).strip()

		if self.evntNm in self.cache:
			self.instance.setPixmap(self.cache[self.evntNm].__deref__())
			return

		self.getPoster()
		if hasattr(self.poster_file, 'name') and os.path.exists(self.poster_file.name):
			self.picload = ePicLoad()
			self.instance.setPixmap(gPixmapPtr())
			size = self.instance.size()
			scale = AVSwitch().getFramebufferScale()
			#0=Width 1=Height 2=Aspect 3=use_cache 4=resize_type 5=Background(#AARRGGBB)
			self.picload.setPara((size.width(), size.height(), scale[0], scale[1], False, 1, '#00000000'))
			if self.picload.startDecode(self.poster_file.name if PY3 else self.poster_file.name.encode('utf-8'), 0, 0, False) == 0:
				ptr = self.picload.getData()
				if ptr:
					if sys.getsizeof(self.cache) > 2048:
						self.cache.popitem(last=False)
					self.cache.update({self.evntNm: ptr})
					self.instance.setPixmap(ptr.__deref__())

			os.remove(self.poster_file.name)
			del self.picload

	def downloadPoster(self, url, suffix='.jpg'):
		try:
			resp = Request(url, headers=HEADERS)
			resp = urlopen(resp, context=context, timeout=timeout)
			self.poster_file = tempfile.NamedTemporaryFile(dir=temp_dir, suffix=suffix,)
			self.poster_file.write(getRespData(resp))
		except:
			try:
				resp.close()
			except:
				pass

	def getPoster(self):
		if not self.intCheck():
			return
		try:
			params = {
				'api_key': tmdb_api,
				'query': self.evntNm,
				'region': 'RU',
				'language': 'ru-RU',
				'append_to_response': 'images',
				'include_image_language': 'null,en',
				'include_adult': 1,
				}
			self.year = self.filterSearch()
			if self.year:
				params.update({
					'primary_release_year': self.year,
					'year': self.year,
					})

			params = urlencode(params)
			resp = Request('https://api.themoviedb.org/3/search/%s?%s' % (self.srch, params), headers=HEADERS)
			resp = urlopen(resp, context=context, timeout=timeout)
			data = json.loads(getRespData(resp))

			if data.get('results'):
				pfname = [_d for _d in data['results'] if _d['poster_path']!='null'][0].get('poster_path')
				if pfname:
					self.downloadPoster('https://image.tmdb.org/t/p/w185%s' % pfname, os.path.splitext(pfname)[1]) 
		except:
			try:
				resp.close()
			except:
				pass
		try:
			params = {
				'seriesname': self.evntNm,
				'language': 'ru-RU',
				}
			params = urlencode(params)
			resp = Request('http://www.thetvdb.com/api/GetSeries.php?%s' % params, headers=HEADERS)
			resp = urlopen(resp, context=context, timeout=timeout)
			data = re.findall('<seriesid>(.*?)</seriesid>', getRespData(resp).decode('utf-8'))

			if not data:
				return

			resp = Request('https://api.thetvdb.com/series/%s/images/query?keyType=poster' % data[0], headers=HEADERS)
			resp = urlopen(resp, context=context, timeout=timeout)
			data = json.loads(getRespData(resp))
			data = data.get('data')
			if data:
				pfname = data[0].get('thumbnail', data[0].get('fileName',''))
				self.downloadPoster('https://artworks.thetvdb.com/banners/%s' % pfname, os.path.splitext(pfname)[1])
		except:
			try:
				resp.close()
			except:
				pass

	def filterSearch(self):
		try:
			self.srch = "multi"
			yr = [ _y for _y in re.findall(r'\d{4}', sd) if '1930' <= _y <= '%s' % gmtime().tm_year ]
			return '%s' % yr[-1] if yr else ''

		except:
			return ''

	def delay(self):
		self.timer = eTimer()
		self.timer.callback.append(self.showPoster)
		self.timer.start(100, True)
