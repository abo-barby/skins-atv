# file for skin BlueMetalFHD
from Components.Renderer.Renderer import Renderer
from enigma import ePixmap, eTimer

class blueFlipClock(Renderer):

    def __init__(self):
        Renderer.__init__(self)
        self.timer = eTimer()
        self.timer.callback.append(self.pollme)

    GUI_WIDGET = ePixmap

    def changed(self, what):
        if not self.suspended:
            value = self.source.text
            if  any(x in value for x in ('H1', 'M1', 'S1')):
                value = value[3:4]
            elif any(x in value for x in ('H2', 'M2', 'S2')):
                value = value[4:5]
            else:
                value = 0
            self.instance.setPixmapFromFile('/usr/share/enigma2/BlueMetalFHD/flipclock/%s.png' % value)

    def pollme(self):
        self.changed(None)

    def onShow(self):
        self.suspended = False
        self.timer.start(200)

    def onHide(self):
        self.suspended = True
        self.timer.stop()
