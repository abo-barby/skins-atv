# -*- coding: utf-8 -*-
# by digiteng...
# file for skin BlueMetalFHD
from Components.Renderer.Renderer import Renderer
from enigma import ePixmap, eTimer, loadPNG
from Tools.Directories import resolveFilename
import re, os, sys, tempfile

pratePath = '/usr/share/enigma2/BlueMetalFHD/icons/parental'

class blueParentalEvent(Renderer):

	def __init__(self):
		Renderer.__init__(self)

	GUI_WIDGET = ePixmap
	def changed(self, what):
		try:
			if not self.instance:
				return
			if what[0] == self.CHANGED_CLEAR:
				self.instance.hide()
			if what[0] != self.CHANGED_CLEAR:
				self.delay()
		except:
			pass

	def showParental(self):
		event = self.source.event
		if not event:
			return

		evnt = event.getEventName()
		fd = evnt + '\n' + event.getShortDescription() + '\n' + event.getExtendedDescription()

		try:
			rate_list = ['0+', '6+', '7+', '10+', '12+', '16+', '18+', 'Od lat: 0', 'Od lat: 6', 'Od lat: 7', 'Od lat: 10', 'Od lat: 12', 'Od lat: 16', 'Od lat: 18']
			ppr = [x.replace('Od lat: ', '') for x in re.findall(r'Od lat: \d{1,2}', fd) if x in rate_list]
			if not ppr:
				ppr = [x.replace('+', '') for x in re.findall(r'\d{1,2}\+', fd) if x in rate_list]
			if ppr:
				parentName = dict(list(zip([x.replace('Od lat: ', '') for x in rate_list], ['0', '6', '6', '12', '12', '16', '18', '0', '6', '6', '12', '12', '16', '18']))).get(ppr[0])
			elif os.path.isfile('/tmp/rating'):
				with open('/tmp/rating') as f:
					ppr = f.readlines()[1].strip()
				parentName = {
						'TV-Y7': '6',
						'TV-14': '12',
						'TV-PG': '16',
						'TV-G': '0',
						'TV-MA': '18',
						'PG-13': '16',
						'R': '18',
						'G': '0',}.get(ppr)
			else:
				parentName = None

			if parentName:
				self.instance.setPixmap(loadPNG(os.path.join(pratePath, 'FSK_%s.png' % parentName)))
				self.instance.show()
			else:
				self.instance.hide()
		except:
			self.instance.hide()

	def delay(self):
		self.timer = eTimer()
		self.timer.callback.append(self.showParental)
		self.timer.start(200, True)
