# -*- coding: utf-8 -*-
# by digiteng
# 11.2020
# file for skin BlueMetalFHD

from Components.VariableValue import VariableValue
from Components.Renderer.Renderer import Renderer
from Components.config import config
from enigma import eSlider

import re, os, sys, socket
import json

PY3 = (sys.version_info[0] == 3)

if PY3:
        from urllib.request import urlopen
        from urllib.parse import quote
else:
        from urllib import quote
        from urllib2 import urlopen

tmdb_api = config.plugins.blueOtherSettings.ApiTmbd.value

REGEX = re.compile(
		r'[0-9]+\+|'
		r'([\(\[]).*?([\)\]])|'
		r'\d{1,3}\:\sodc|'
		r'\:\sodc|'
		r'\d{1,3}\s\(odc|'
		r'\s\(odc|'
		r'(x|X|х|Х|м|М)/ф|'
		r'(т|Т)/с|'
		r'\d{1,3}-я\sсерия|'
		r'(\s\-(.*?).*)|'
		r'[\^\{\}\$\\/\*"<\:>,-\.\|]', re.DOTALL)

class blueStarsEvent(VariableValue, Renderer):
	def __init__(self):
		Renderer.__init__(self)
		VariableValue.__init__(self)
		self.__start = 0
		self.__end = 100

	GUI_WIDGET = eSlider
	def changed(self, what):
		rtng = None
		rating = 0
		if what[0] == self.CHANGED_CLEAR:
			(self.range, self.value) = ((0, 1), 0)
			return
		event = self.source.event
		if event:
			evnt = event.getEventName()
			evntNm = REGEX.sub('', event.getEventName().split('.')[0]).strip()
			try:
				url_tmbd = "https://api.themoviedb.org/3/search/multi?api_key={}&query={}".format(tmdb_api, quote(evntNm))
				rating = json.load(urlopen(url_tmbd))["results"][0]["vote_average"]
				if rating:
					rtng = int(10*(float(rating)))
				else:
					rtng = 0
			except:
				pass
		else:
			rtng = 0
		range = 100
		value = rtng
		(self.range, self.value) = ((0, range), value)

	def postWidgetCreate(self, instance):
		instance.setRange(self.__start, self.__end)

	def setRange(self, range):
		(self.__start, self.__end) = range
		if self.instance is not None:
			self.instance.setRange(self.__start, self.__end)

	def getRange(self):
		return self.__start, self.__end
	range = property(getRange, setRange)
