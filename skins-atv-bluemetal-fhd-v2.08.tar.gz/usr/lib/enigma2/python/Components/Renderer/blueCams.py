# file for skin BlueMetalFHD
from Components.Renderer.Renderer import Renderer
from enigma import ePixmap, ePicLoad, iServiceInformation
from Tools.Directories import fileExists, SCOPE_SKIN_IMAGE, SCOPE_CURRENT_SKIN, resolveFilename
from Components.Converter.Poll import Poll

class blueCams(Renderer, Poll):

	def __init__(self):
		Poll.__init__(self)
		Renderer.__init__(self)
		self.nameCache = {}
		self.pngname = ''
		self.path = 'usr/share/enigma2/BlueMetalFHD/icons/crypt/'

	def applySkin(self, desktop, parent):
		attribs = []
		for attrib, value in self.skinAttributes:
			if attrib == 'path':
				self.path = value
			else:
				attribs.append((attrib, value))

		self.skinAttributes = attribs
		return Renderer.applySkin(self, desktop, parent)

	GUI_WIDGET = ePixmap

	def changed(self, what):
		self.poll_interval = 2000
		self.poll_enabled = True
		sname = 'UNKNOWN'
		caid = ''
		cfgfile = '/tmp/ecm.info'
		if self.instance:
			pngname = ''
			if what[0] != self.CHANGED_CLEAR:
				service = self.source.service
				if service:
					info = service and service.info()
					if info:
						caids = info.getInfoObject(iServiceInformation.sCAIDs)
						try:
							f = open(cfgfile, 'r')
							content = f.read()
							f.close()
						except:
							content = ''

						if len(caids) > 0 and content == '':
							for caid in caids:
								if ("%0.4X" % int(caid))[:4] >= "2600" and ("%0.4X" % int(caid))[:4] <= "26FF":
									sname = 'BISS'
								elif ("%0.4X" % int(caid))[:4] >= "0100" and ("%0.4X" % int(caid))[:4] <= "01FF":
									sname = 'SECA MEDIAGUARD'
								elif ("%0.4X" % int(caid))[:4] >= "0600" and ("%0.4X" % int(caid))[:4] <= "06FF":
									sname = 'IRDETO'
								elif ("%0.4X" % int(caid))[:4] >= "0500" and ("%0.4X" % int(caid))[:4] <= "05FF":
									sname = 'VIACCES'
								elif ("%0.4X" % int(caid))[:4] >= "1800" and ("%0.4X" % int(caid))[:4] <= "18FF":
									sname = 'NAGRAVISION'
								elif ("%0.4X" % int(caid))[:4] == "1702" or ("%0.4X" % int(caid))[:4] == "1722" or ("%0.4X" % int(caid))[:4] == "1762":
									sname = 'BETACRYPT'
								elif ("%0.4X" % int(caid))[:4] >= "0900" and ("%0.4X" % int(caid))[:4] <= "09FF":
									sname = 'NDS-VIDEOGUARD'
								elif ("%0.4X" % int(caid))[:4] >= "0B00" and ("%0.4X" % int(caid))[:4] <= "0BFF":
									sname = 'CONAX'
								elif ("%0.4X" % int(caid))[:4] >= "0D00" and ("%0.4X" % int(caid))[:4] <= "0DFF":
									sname = 'CRYPTOWORKS'
								elif ("%0.4X" % int(caid))[:4] >= "4A00" and ("%0.4X" % int(caid))[:4] <= "4AE9" or ("%0.4X" % int(caid))[:4] >= "5000" and ("%0.4X" % int(caid))[:4] <= "50FF" or ("%0.4X" % int(caid))[:4] == "7BE0" or ("%0.4X" % int(caid))[:4] >= "0700" and ("%0.4X" % int(caid))[:4] <= "07FF" or ("%0.4X" % int(caid))[:4] >= "4700" and ("%0.4X" % int(caid))[:4] <= "47FF":
									sname = 'DRE-CRYPT'
								elif ("%0.4X" % int(caid))[:4] >= "2700" and ("%0.4X" % int(caid))[:4] <= "27FF":
									sname = 'EXSET'
								elif ("%0.4X" % int(caid))[:4] >= "0E00" and ("%0.4X" % int(caid))[:4] <= "0EFF":
									sname = 'POWERVU'
								elif ("%0.4X" % int(caid))[:4] >= "1000" and ("%0.4X" % int(caid))[:4] <= "10FF":
									sname = 'TANDBERG'
								elif ("%0.4X" % int(caid))[:4] == "1700" or ("%0.4X" % int(caid))[:4] == "1701" or ("%0.4X" % int(caid))[:4] >= "1703" and ("%0.4X" % int(caid))[:4] <= "1721" or ("%0.4X" % int(caid))[:4] >= "1723" and ("%0.4X" % int(caid))[:4] <= "1761" or ("%0.4X" % int(caid))[:4] >= "1763" and ("%0.4X" % int(caid))[:4] <= "17FF" or ("%0.4X" % int(caid))[:4] >= "5601" and ("%0.4X" % int(caid))[:4] <= "5604":
									sname = 'VERIMATRIX'
								elif ("%0.4X" % int(caid))[:4] >= "5501" and ("%0.4X" % int(caid))[:4] <= "55FF" or ("%0.4X" % int(caid))[:4] == "4AEE" or ("%0.4X" % int(caid))[:4] == "4AF8":
									sname = 'BUL-CRYPT'
						elif len(caids) > 0 and content != '':
							contentInfo = content.split('\n')
							for line in contentInfo:
								if line.startswith('caid:'):
									caid = self.parseEcmInfoLine(line)
									if caid.__contains__('x'):
										idx = caid.index('x')
										caid = caid[idx + 1:]
										if len(caid) == 3:
											caid = '0%s' % caid
										caid = caid[:4]
										caid = caid.upper()
										if caid >= '2600' and caid <= '26FF':
											sname = 'BISS'
										elif caid >= "0100" and caid <= "01FF":
											sname = 'SECA MEDIAGUARD'
										elif caid >= "0600" and caid <= "06FF":
											sname = 'IRDETO'
										elif caid >= "0500" and caid <= "05FF":
											sname = 'VIACCES'
										elif caid >= "1800" and caid <= "18FF":
											sname = 'NAGRAVISION'
										elif caid == "1702" or caid == "1722" or caid == "1762":
											sname = 'BETACRYPT'
										elif caid >= "0900" and caid <= "09FF":
											sname = 'NDS-VIDEOGUARD'
										elif caid >= "0B00" and caid <= "0BFF":
											sname = 'CONAX'
										elif caid >= "0D00" and caid <= "0DFF" or caid >= "4900" and caid <= "49FF":
											sname = 'CRYPTOWORKS'
										elif caid >= "4A00" and caid <= "4AE9" or caid >= "5000" and caid <= "50FF" or caid == "7BE0" or caid >= "0700" and caid <= "07FF" or caid >= "4700" and caid <= "47FF":
											sname = 'DRE-CRYPT'
										elif caid >= "2700" and caid <= "27FF":
											sname = 'EXSET'
										elif caid >= "0E00" and caid <= "0EFF":
											sname = 'POWERVU'
										elif caid >= "1000" and caid <= "10FF":
											sname = 'TANDBERG'
										elif caid == "1700" or caid == "1701" or caid >= "1703" and caid <= "1721" or caid >= "1723" and caid <= "1761" or caid >= "1763" and caid <= "17FF" or caid >= "5601" and caid <= "5604":
											sname = 'VERIMATRIX'
										elif caid >= "5501" and caid <= "55FF" or caid == "4AEE" or caid == "4AF8":
											sname = 'BUL-CRYPT'
								elif line.startswith('=====') or line.startswith('CAID') or line.startswith('***'):
									caid = self.parseInfoLine(line)
									if caid.__contains__('x'):
										idx = caid.index('x')
										caid = caid[idx + 1:]
										caid = caid[:4]
										caid = caid.upper()
										if caid >= '2600' and caid <= '26FF':
											sname = 'BISS'
										elif caid >= "0100" and caid <= "01FF":
											sname = 'SECA MEDIAGUARD'
										elif caid >= "0600" and caid <= "06FF":
											sname = 'IRDETO'
										elif caid >= "0500" and caid <= "05FF":
											sname = 'VIACCES'
										elif caid >= "1800" and caid <= "18FF":
											sname = 'NAGRAVISION'
										elif caid == "1702" or caid == "1722" or caid == "1762":
											sname = 'BETACRYPT'
										elif caid >= "0900" and caid <= "09FF":
											sname = 'NDS-VIDEOGUARD'
										elif caid >= "0B00" and caid <= "0BFF":
											sname = 'CONAX'
										elif caid >= "0D00" and caid <= "0DFF" or caid >= "4900" and caid <= "49FF":
											sname = 'CRYPTOWORKS'
										elif caid >= "4A00" and caid <= "4AE9" or caid >= "5000" and caid <= "50FF" or caid == "7BE0" or caid >= "0700" and caid <= "07FF" or caid >= "4700" and caid <= "47FF":
											sname = 'DRE-CRYPT'
										elif caid >= "2700" and caid <= "27FF":
											sname = 'EXSET'
										elif caid >= "0E00" and caid <= "0EFF":
											sname = 'POWERVU'
										elif caid >= "1000" and caid <= "10FF":
											sname = 'TANDBERG'
										elif caid == "1700" or caid == "1701" or caid >= "1703" and caid <= "1721" or caid >= "1723" and caid <= "1761" or caid >= "1763" and caid <= "17FF" or caid >= "5601" and caid <= "5604":
											sname = 'VERIMATRIX'
										elif caid >= "5501" and caid <= "55FF" or caid == "4AEE" or caid == "4AF8":
											sname = 'BUL-CRYPT'
						elif caids is None and content != '':
							sname = 'FTA'
						else:
							sname = 'FTA'
					works = True
					if works == True:
						pngname = self.nameCache.get(sname, '')
						if pngname == '':
							pngname = self.findPicon(sname)
							if pngname != '':
								self.nameCache[sname] = pngname
						if pngname == '':
							pngname = self.nameCache.get(sname, '')
							if pngname == '':
								pngname = self.findPicon(sname)
								if pngname == '':
									tmp = resolveFilename(SCOPE_CURRENT_SKIN, 'CRYPT.png')
									if fileExists(tmp):
										pngname = tmp
									else:
										pngname = resolveFilename(SCOPE_SKIN_IMAGE, 'usr/share/enigma2/BlueMetalFHD/icons/crypt/CRYPT.png')
								self.nameCache['default'] = pngname
						if self.pngname != pngname:
							self.pngname = pngname
							self.instance.setScale(1)
							self.instance.setPixmapFromFile(pngname)
		return

	def parseEcmInfoLine(self, line):
		if line.__contains__(':'):
			idx = line.index(':')
			line = line[idx + 1:]
			line = line.replace('\n', '')
			while line.startswith(' '):
				line = line[1:]

			while line.endswith(' '):
				line = line[:-1]

			return line
		else:
			return ''

	def parseInfoLine(self, line):
		if line.__contains__('CaID') or line.__contains__('CAID'):
			idx = line.index('D')
			line = line[idx + 1:]
			line = line.replace('\n', '')
			while line.startswith(' '):
				line = line[1:]

			while line.endswith(' '):
				line = line[:-1]

			return line
		else:
			return ''

	def findPicon(self, serviceName):
		if serviceName:
			pngname = self.path + serviceName + '.png'
			if fileExists(pngname):
				return pngname
		return ''