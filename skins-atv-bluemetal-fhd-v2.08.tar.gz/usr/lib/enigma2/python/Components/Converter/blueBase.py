﻿#  blueBase converter
# file for skin BlueMetalFHD
# code optimization Dorik1972

from __future__ import absolute_import
from Components.Converter.Converter import Converter
from Components.Element import cached
import NavigationInstance
from Components.Converter.Poll import Poll
from enigma import iServiceInformation, iPlayableService, eServiceReference
from Tools.Transponder import ConvertToHumanReadable
from Components.config import config
from Tools.Directories import fileExists


# codec map
codecs = {
	-1: "N/A",
	0: "MPEG2",
	1: "AVC",
	2: "H263",
	3: "VC1",
	4: "MPEG4-VC",
	5: "VC1-SM",
	6: "MPEG1",
	7: "HEVC",
	8: "VP8",
	9: "VP9",
	10: "XVID",
	11: "N/A 11",
	12: "N/A 12",
	13: "DIVX 3.11",
	14: "DIVX 4",
	15: "DIVX 5",
	16: "AVS",
	17: "N/A 17",
	18: "VP6",
	19: "N/A 19",
	20: "N/A 20",
	21: "SPARK"}

gamma_data = {-1: ' ',
	0: 'SDR',
	1: 'HDR',
	2: 'HDR10',
	3: 'HLG',
	4: ' '}

class blueBase(Poll, Converter, object):
	RESCODEC = 1
	VIDEOCODEC = 2
	VIDEOSIZE = 3
	IS1080 = 4
	IS720 = 5
	IS576 = 6
	IS1440 = 7
	IS2160 = 8
	IS480 = 9
	IS360 = 10
	HDRINFO = 15
	IS_CABLE = 16
	IS_SATELLITE_S = 17
	IS_SATELLITE_S2 = 18
	IS_TERRESTRIAL_T = 19
	IS_TERRESTRIAL_T2 = 20
	HAS_HBBTV = 21
	IS_STREAMTV = 22


	def __init__(self, type):
		Converter.__init__(self, type)
		self.type = type
		self.short_list = True
		Poll.__init__(self)
		self.poll_interval = 1000
		self.poll_enabled = True
		self.list = []
		self.type = {
			"ResCodec": self.RESCODEC,
			"VideoCodec": self.VIDEOCODEC,
			"VideoSize": self.VIDEOSIZE,
			"Is1080": self.IS1080,
			"Is720": self.IS720,
			"Is576": self.IS576,
			"Is1440": self.IS1440,
			"Is2160": self.IS2160,
			"Is480": self.IS480,
			"Is360": self.IS360,
			"HDRInfo": self.HDRINFO,
			"IsCable": self.IS_CABLE,
			"IsSatelliteS": self.IS_SATELLITE_S,
			"IsSatelliteS2": self.IS_SATELLITE_S2,
			"IsTerrestrialT": self.IS_TERRESTRIAL_T,
			"IsTerrestrialT2": self.IS_TERRESTRIAL_T2,
			"HasHBBTV": self.HAS_HBBTV,
			"IsStreamTV": self.IS_STREAMTV, }[type]

############################################

	def _isHDMIIn(self, info):
		return eServiceReference(info.getInfoString(iServiceInformation.sServiceref)).type == eServiceReference.idServiceHDMIIn

	def getServiceInfoString(self, info, what, convert=lambda x: "%d" % x):
		if self._isHDMIIn(info):
			return "N/A"
		v = info.getInfo(what)
		if v == -1:
			return "N/A"
		if v == -2:
			return info.getInfoString(what)
		return convert(v)

	def _getProcVal(self, pathname, base=10):
		val = None
		try:
			with open(pathname, "r") as f:
				val = int(f.read(), base)
			if val >= 2 ** 31:
				val -= 2 ** 32
		except Exception as e:
			pass
		return val

	def _getVal(self, pathname, info, infoVal, base=10):
		if self._isHDMIIn(info):
			return None
		val = self._getProcVal(pathname, base=base)
		return val if val is not None else info.getInfo(infoVal)

	def _getValInt(self, pathname, info, infoVal, base=10, default=-1):
		val = self._getVal(pathname, info, infoVal, base)
		return val if val is not None else default

	def _getValStr(self, pathname, info, infoVal, base=10, convert=lambda x: "%d" % x):
		if self._isHDMIIn(info):
			return "N/A"
		val = self._getProcVal(pathname, base=base)
		return convert(val) if val is not None else self.getServiceInfoString(info, infoVal, convert)

	def _getVideoHeight(self, info):
		return self._getValInt("/proc/stb/vmpeg/0/yres", info, iServiceInformation.sVideoHeight, base=16)

	def _getVideoHeightStr(self, info, convert=lambda x: "%d" % x if x > 0 else "?"):
		return self._getValStr("/proc/stb/vmpeg/0/yres", info, iServiceInformation.sVideoHeight, base=16, convert=convert)

	def _getVideoWidthStr(self, info, convert=lambda x: "%d" % x if x > 0 else "?"):
		return self._getValStr("/proc/stb/vmpeg/0/xres", info, iServiceInformation.sVideoWidth, base=16, convert=convert)

	def _getFrameRateStr(self, info, convert=lambda x: "%d fps" % (x/1000.) if x > 0 else ""):
		return self._getValStr("/proc/stb/vmpeg/0/framerate", info, iServiceInformation.sFrameRate, convert=convert)

	def _getProgressiveStr(self, info, convert=lambda x: ("i", "p", "", " ")[x]):
		return self._getValStr("/proc/stb/vmpeg/0/progressive", info, iServiceInformation.sProgressive, convert=convert)


	def videosize(self, info):
		return "%sx%s%s" % (self._getVideoWidthStr(info), self._getVideoHeightStr(info), self._getProgressiveStr(info))

	def videocodec(self, info):
		return "%s" % codecs.get(info.getInfo(iServiceInformation.sVideoType), "N/A")


	def hdr(self, info):
		gamma = gamma_data[info.getInfo(iServiceInformation.sGamma)]

		if gamma:
			return str(gamma)
		else:
			return ""

	@cached
	def getText(self):
		service = self.source.service
		info = service and service.info()
		if not info:
			return ""

		if self.type == self.VIDEOCODEC:
			return self.videocodec(info)
		elif self.type == self.VIDEOSIZE:
			return self.videosize(info)
		elif self.type == self.RESCODEC:
			return "%s %s %s" % (self.videosize(info), self._getFrameRateStr(info), self.hdr(info))
		elif self.type == self.HDRINFO:
			return self.hdr(info)

	text = property(getText)


	@cached
	def getBoolean(self):
		service = self.source.service
		info = service and service.info()
		if not info:
			return False

		yresol = self._getVideoHeight(info)
		self.tpdata = info.getInfoObject(iServiceInformation.sTransponderData)

		if self.tpdata:
			type = self.tpdata.get('tuner_type', '')
		else:
			type = 'IP-TV'

		if (self.type == self.IS1080):
			if (900 <= yresol <= 1090):
				return True
		elif (self.type == self.IS720):
			if (601 <= yresol <= 800):
				return True
		elif (self.type == self.IS576):
			if (501 <= yresol <= 600):
				return True
		elif (self.type == self.IS1440):
			if (1300 <= yresol <= 1500):
				return True
		elif (self.type == self.IS2160):
			if (2150 <= yresol <= 2170):
				return True
		elif (self.type == self.IS480):
			if (380 <= yresol <= 500):
				return True
		elif (self.type == self.IS360):
			if (200 <= yresol <= 379):
				return True
		elif self.type == self.IS_CABLE:
			if type == 'DVB-C':
				return True
		elif self.type == self.IS_SATELLITE_S:
			if type == 'DVB-S' and service.streamed() is None:
				if self.tpdata.get('system', 0) == 0:
					return True
		elif self.type == self.IS_SATELLITE_S2:
			if type == 'DVB-S' and service.streamed() is None:
				if self.tpdata.get('system', 0) == 1:
					return True
		elif self.type == self.IS_TERRESTRIAL_T:
			if type == 'DVB-T' and service.streamed() is None:
				if self.tpdata.get('system', 0) == 0:
					return True
		elif self.type == self.IS_TERRESTRIAL_T2:
			if type == 'DVB-T' and service.streamed() is None:
				if self.tpdata.get('system', 0) == 1:
					return True
		elif self.type == self.HAS_HBBTV:
			try:
				return info.getInfoString(iServiceInformation.sHBBTVUrl) != ""
			except:
				pass
		elif self.type == self.IS_STREAMTV:
			if service.streamed() is not None:
				return True
		return False

	boolean = property(getBoolean)

	def changed(self, what):
		if what[0] == self.CHANGED_SPECIFIC and what[1] == iPlayableService.evUpdatedInfo or what[0] == self.CHANGED_POLL:
			Converter.changed(self, what)
