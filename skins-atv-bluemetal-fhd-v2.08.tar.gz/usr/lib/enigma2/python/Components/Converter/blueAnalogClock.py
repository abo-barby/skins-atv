# file for skin BlueMetalFHD
from Components.Converter.Converter import Converter
from Components.Element import cached
from time import localtime, strftime

class blueAnalogClock(Converter, object):
    LOCK = 1
    SECHAND = 2
    MINHAND = 3
    HOURHAND = 4

    def __init__(self, type):
        Converter.__init__(self, type)
        self.type = {'secHand' : self.SECHAND,
                     'minHand' : self.MINHAND,
                     'hourHand': self.HOURHAND, }.get(type, self.LOCK)

    @cached
    def getValue(self):

        t = self.source.time                                                                                                                          
        if t is None:
            return 0

        if self.type == self.SECHAND:
            return localtime(t).tm_sec

        elif self.type == self.MINHAND:
            return localtime(t).tm_min

        elif self.type == self.HOURHAND:
            t = localtime(t)
            h = t.tm_hour
            m = t.tm_min
            if h > 11:
                h = h - 12
            return h * 5 + m / 12
        else:
            return 0

    value = property(getValue)
