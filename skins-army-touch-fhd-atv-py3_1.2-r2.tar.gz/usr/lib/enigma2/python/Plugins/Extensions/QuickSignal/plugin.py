##
## Quick Signal
## by big-town
## modifed by Metabox1
## 
from Components.ActionMap import ActionMap
from Components.config import config, ConfigSubsection, ConfigYesNo
from GlobalActions import globalActionMap
from Plugins.Plugin import PluginDescriptor
from Screens.Screen import Screen

##############################################################################
config.plugins.QuickSignal = ConfigSubsection()
config.plugins.QuickSignal.enabled = ConfigYesNo(default=True)
config.plugins.QuickSignal.enabled.value = False

##############################################################################


SKIN = """
    <screen name="QuickSignalScreen" position="50,40" size="1180,650"  title="Quick Signal Info">
            <widget source="session.FrontendStatus" render="Label"    position="490,1" zPosition="2" size="200,50" font="Regular;45" foregroundColor="#00ff0080" halign="center" valign="center" transparent="1" >
            <convert type="FrontendInfo">SNRdB</convert>
        </widget>
        
        
        <!-- SNR -->
        <eLabel name="snr" text="SNR:"                              position="5,100" size="100,35" font="Regular;33" halign="right" foregroundColor="#00ff0080" transparent="1" />
        <widget source="session.FrontendStatus" render="Progress"  position="135,60" size="910,100" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/QuickSignal/icons_quick/icon_snr-scan.png"    zPosition="2" borderWidth="4" borderColor="#007b68ee">
            <convert type="FrontendInfo">SNR</convert>
        </widget>
        <widget source="session.FrontendStatus" render="Label"    position="1080,100" size="100,35" font="Regular;33" foregroundColor="#00ff0080" transparent="1">
            <convert type="FrontendInfo">SNR</convert>
        </widget>
        
        <!-- AGC -->
        <eLabel name="agc" text="AGC:"                              position="5,200" size="100,35" font="Regular;33" halign="right" foregroundColor="#00ff0080" transparent="1" />
        <widget source="session.FrontendStatus" render="Progress" position="135,180" size="910,100" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/QuickSignal/icons_quick/icon_snr-scan.png"    zPosition="2" borderWidth="4" borderColor="#007b68ee">
            <convert type="FrontendInfo">AGC</convert>
        </widget>
        <widget source="session.FrontendStatus" render="Label"    position="1080,200" size="100,35" font="Regular;33" foregroundColor="#00ff0080" transparent="1">
            <convert type="FrontendInfo">AGC</convert>
        </widget>
        
        <eLabel position="219,290" size="740,2" backgroundColor="#00fa8072" zPosition="4" />
        <eLabel position="219,445" size="740,2" backgroundColor="#00fa8072" zPosition="4" />
        <eLabel position="219,475" size="740,2" backgroundColor="#00fa8072" zPosition="4" />
        <eLabel position="219,505" size="740,2" backgroundColor="#00fa8072" zPosition="4" />
        <eLabel position="224,535" size="730,2" backgroundColor="#00fa8072" zPosition="4" />
        <eLabel position="246,565" size="686,2" backgroundColor="#00fa8072" zPosition="4" />
  
  <widget source="session.CurrentService" render="Label" position="219,300" size="740,145" font="Regular; 23" zPosition="2" backgroundColor="background" foregroundColor="#000099ff" transparent="1" valign="top" noWrap="1" halign="center">
    <convert type="QuickEcmInfo">ecmfile</convert>
  </widget>
  
  <widget source="session.CurrentService" render="Label" position="219,480" size="640,25" font="Regular; 22" zPosition="2"  backgroundColor="background" foregroundColor="#00fec000" transparent="1" valign="top" halign="left">
    <convert type="QuickEcmInfo">caids</convert>
  </widget>
  <widget source="session.CurrentService" render="Label" position="879,480" size="80,25" font="Regular; 22" zPosition="3" backgroundColor="background" foregroundColor="#00fec000" transparent="1" valign="top" halign="right">
    <convert type="QuickEcmInfo">activecaid</convert>
  </widget>
  <widget source="session.CurrentService" render="Label" position="219,510" size="740,25" font="Regular; 22" zPosition="2" backgroundColor="background" foregroundColor="#0000ff00" transparent="1" valign="top" halign="center">
    <convert type="QuickEcmInfo">pids</convert>
  </widget>
  <widget source="session.CurrentService" render="Label" position="244,540" size="690,25" font="Regular; 22" zPosition="2" backgroundColor="background" foregroundColor="#007b68ee" transparent="1" valign="top" halign="center">
    <convert type="QuickEcmInfo">bitrate</convert>
  </widget>
  <widget source="session.CurrentService" render="Label" position="219,449" size="310,25" font="Regular; 22" zPosition="2" backgroundColor="background" foregroundColor="#00ff00ff" transparent="1" valign="top" halign="left">
    <convert type="CamdInfo3">Camd</convert>
  </widget> 
  <widget source="session.CurrentService" render="Label" position="729,449" size="230,25" font="Regular; 22" zPosition="3" backgroundColor="background" foregroundColor="#00ff00ff" transparent="1" valign="top" halign="right">
    <convert type="QuickEcmInfo">txtcaid</convert>
  </widget> 

    
    <widget source="session.FrontendStatus" render="Pixmap"   position="135,340" size="4,100" zPosition="2" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/QuickSignal/icons_quick/icon_ber-scan_on.png" transparent="1" >
            <convert type="QuickSignalText">BerNum</convert> <convert type="ValueRange">1,10</convert> <convert type="ConditionalShowHide"/> 
                </widget>
        <widget source="session.FrontendStatus" render="Pixmap"   position="135,340" size="8,100" zPosition="2" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/QuickSignal/icons_quick/icon_ber-scan_on.png" transparent="1" >
            <convert type="QuickSignalText">BerNum</convert> <convert type="ValueRange">11,20</convert> <convert type="ConditionalShowHide"/> 
                </widget>
        <widget source="session.FrontendStatus" render="Pixmap"   position="135,340" size="12,100" zPosition="2" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/QuickSignal/icons_quick/icon_ber-scan_on.png" transparent="1" >
            <convert type="QuickSignalText">BerNum</convert> <convert type="ValueRange">21,30</convert> <convert type="ConditionalShowHide"/> 
                </widget>
        <widget source="session.FrontendStatus" render="Pixmap"   position="135,340" size="16,100" zPosition="2" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/QuickSignal/icons_quick/icon_ber-scan_on.png" transparent="1" >
            <convert type="QuickSignalText">BerNum</convert> <convert type="ValueRange">31,40</convert> <convert type="ConditionalShowHide"/> 
                </widget>
        <widget source="session.FrontendStatus" render="Pixmap"   position="135,340" size="20,100" zPosition="2" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/QuickSignal/icons_quick/icon_ber-scan_on.png" transparent="1" >
            <convert type="QuickSignalText">BerNum</convert> <convert type="ValueRange">41,50</convert> <convert type="ConditionalShowHide"/> 
                </widget>
                <widget source="session.FrontendStatus" render="Pixmap"   position="135,340" size="25,100" zPosition="2" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/QuickSignal/icons_quick/icon_ber-scan_on.png" transparent="1" >
            <convert type="QuickSignalText">BerNum</convert> <convert type="ValueRange">51,60</convert> <convert type="ConditionalShowHide"/> 
                </widget>
                <widget source="session.FrontendStatus" render="Pixmap"   position="135,340" size="30,100" zPosition="2" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/QuickSignal/icons_quick/icon_ber-scan_on.png" transparent="1" >
            <convert type="QuickSignalText">BerNum</convert> <convert type="ValueRange">61,70</convert> <convert type="ConditionalShowHide"/> 
                </widget>
                <widget source="session.FrontendStatus" render="Pixmap"   position="135,340" size="35,100" zPosition="2" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/QuickSignal/icons_quick/icon_ber-scan_on.png" transparent="1" >
            <convert type="QuickSignalText">BerNum</convert> <convert type="ValueRange">71,80</convert> <convert type="ConditionalShowHide"/> 
                </widget>
                <widget source="session.FrontendStatus" render="Pixmap"   position="135,340" size="40,100" zPosition="2" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/QuickSignal/icons_quick/icon_ber-scan_on.png" transparent="1" >
            <convert type="QuickSignalText">BerNum</convert> <convert type="ValueRange">81,90</convert> <convert type="ConditionalShowHide"/> 
                </widget>
        <widget source="session.FrontendStatus" render="Pixmap"   position="135,340" size="45,100" zPosition="2" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/QuickSignal/icons_quick/icon_ber-scan_on.png" transparent="1" >
            <convert type="QuickSignalText">BerNum</convert> <convert type="ValueRange">91,100</convert> <convert type="ConditionalShowHide"/> 
                </widget>
                <widget source="session.FrontendStatus" render="Pixmap"   position="135,340" size="50,100" zPosition="2" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/QuickSignal/icons_quick/icon_ber-scan_on.png" transparent="1" >
            <convert type="QuickSignalText">BerNum</convert> <convert type="ValueRange">101,200</convert> <convert type="ConditionalShowHide"/> 
                </widget>
                <widget source="session.FrontendStatus" render="Pixmap"   position="135,340" size="55,100" zPosition="2" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/QuickSignal/icons_quick/icon_ber-scan_on.png" transparent="1" >
            <convert type="QuickSignalText">BerNum</convert> <convert type="ValueRange">201,300</convert> <convert type="ConditionalShowHide"/> 
                </widget>
                <widget source="session.FrontendStatus" render="Pixmap"   position="135,340" size="60,100" zPosition="2" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/QuickSignal/icons_quick/icon_ber-scan_on.png" transparent="1" >
            <convert type="QuickSignalText">BerNum</convert> <convert type="ValueRange">301,400</convert> <convert type="ConditionalShowHide"/> 
                </widget>
                <widget source="session.FrontendStatus" render="Pixmap"   position="135,340" size="65,100" zPosition="2" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/QuickSignal/icons_quick/icon_ber-scan_on.png" transparent="1" >
            <convert type="QuickSignalText">BerNum</convert> <convert type="ValueRange">401,500</convert> <convert type="ConditionalShowHide"/> 
                </widget>
                <widget source="session.FrontendStatus" render="Pixmap"   position="135,340" size="70,100" zPosition="2" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/QuickSignal/icons_quick/icon_ber-scan_on.png" transparent="1" >
            <convert type="QuickSignalText">BerNum</convert> <convert type="ValueRange">501,600</convert> <convert type="ConditionalShowHide"/> 
                </widget>
                <widget source="session.FrontendStatus" render="Pixmap"   position="135,340" size="75,100" zPosition="2" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/QuickSignal/icons_quick/icon_ber-scan_on.png" transparent="1" >
            <convert type="QuickSignalText">BerNum</convert> <convert type="ValueRange">601,700</convert> <convert type="ConditionalShowHide"/> 
                </widget>
                <widget source="session.FrontendStatus" render="Pixmap"   position="135,340" size="80,100" zPosition="2" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/QuickSignal/icons_quick/icon_ber-scan_on.png" transparent="1" >
            <convert type="QuickSignalText">BerNum</convert> <convert type="ValueRange">701,800</convert> <convert type="ConditionalShowHide"/> 
                </widget>
                <widget source="session.FrontendStatus" render="Pixmap"   position="135,340" size="85,100" zPosition="2" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/QuickSignal/icons_quick/icon_ber-scan_on.png" transparent="1" >
            <convert type="QuickSignalText">BerNum</convert> <convert type="ValueRange">801,900</convert> <convert type="ConditionalShowHide"/> 
                </widget>
                <widget source="session.FrontendStatus" render="Pixmap"   position="135,340" size="90,100" zPosition="2" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/QuickSignal/icons_quick/icon_ber-scan_on.png" transparent="1" >
            <convert type="QuickSignalText">BerNum</convert> <convert type="ValueRange">901,1000</convert> <convert type="ConditionalShowHide"/> 
                </widget>
                <widget source="session.FrontendStatus" render="Pixmap"   position="135,340" size="95,100" zPosition="2" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/QuickSignal/icons_quick/icon_ber-scan_on.png" transparent="1" >
            <convert type="QuickSignalText">BerNum</convert> <convert type="ValueRange">1001,5000</convert> <convert type="ConditionalShowHide"/> 
                </widget>
                <widget source="session.FrontendStatus" render="Pixmap"   position="135,340" size="100,100" zPosition="2" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/QuickSignal/icons_quick/icon_ber-scan_on.png" transparent="1" >
            <convert type="QuickSignalText">BerNum</convert> <convert type="ValueRange">5001,10000</convert> <convert type="ConditionalShowHide"/> 
                </widget>
                <widget source="session.FrontendStatus" render="Pixmap"   position="135,340" size="150,100" zPosition="2" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/QuickSignal/icons_quick/icon_ber-scan_on.png" transparent="1" >
            <convert type="QuickSignalText">BerNum</convert> <convert type="ValueRange">9001,10000</convert> <convert type="ConditionalShowHide"/> 
                </widget>
                <widget source="session.FrontendStatus" render="Pixmap"   position="135,340" size="200,100" zPosition="2" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/QuickSignal/icons_quick/icon_ber-scan_on.png" transparent="1" >
            <convert type="QuickSignalText">BerNum</convert> <convert type="ValueRange">10001,50000</convert> <convert type="ConditionalShowHide"/> 
                </widget>
                <widget source="session.FrontendStatus" render="Pixmap"   position="135,340" size="250,100" zPosition="2" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/QuickSignal/icons_quick/icon_ber-scan_on.png" transparent="1" >
            <convert type="QuickSignalText">BerNum</convert> <convert type="ValueRange">50001,100001</convert> <convert type="ConditionalShowHide"/> 
                </widget>
                <widget source="session.FrontendStatus" render="Pixmap"   position="135,340" size="400,100" zPosition="2" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/QuickSignal/icons_quick/icon_ber-scan_on.png" transparent="1" >
            <convert type="QuickSignalText">BerNum</convert> <convert type="ValueRange">100001,150000</convert> <convert type="ConditionalShowHide"/> 
                </widget>
                <widget source="session.FrontendStatus" render="Pixmap"   position="135,340" size="600,100" zPosition="2" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/QuickSignal/icons_quick/icon_ber-scan_on.png" transparent="1" >
            <convert type="QuickSignalText">BerNum</convert> <convert type="ValueRange">150001,200000</convert> <convert type="ConditionalShowHide"/> 
                </widget>
                <widget source="session.FrontendStatus" render="Pixmap"   position="135,340" size="700,100" zPosition="2" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/QuickSignal/icons_quick/icon_ber-scan_on.png" transparent="1" >
            <convert type="QuickSignalText">BerNum</convert> <convert type="ValueRange">200001,250000</convert> <convert type="ConditionalShowHide"/> 
                </widget>
                <widget source="session.FrontendStatus" render="Pixmap"   position="135,340" size="800,100" zPosition="2" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/QuickSignal/icons_quick/icon_ber-scan_on.png" transparent="1" >
            <convert type="QuickSignalText">BerNum</convert> <convert type="ValueRange">250001,319999</convert> <convert type="ConditionalShowHide"/> 
                </widget>
                <widget source="session.FrontendStatus" render="Pixmap"   position="135,340" size="910,100" zPosition="2" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/QuickSignal/icons_quick/icon_ber-scan_on.png" transparent="1" >
            <convert type="QuickSignalText">BerNum</convert> <convert type="ValueRange">320000,320000</convert> <convert type="ConditionalShowHide"/> 
                </widget>
                
            <!-- Picon -->
            <ePixmap position="266,576" size="116,73" zPosition="1" transparent="1" alphatest="on" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/QuickSignal/icons_quick/picon_fon.png" />
        <widget source="session.CurrentService" render="Picon"     position="274,583" size="100,60" zPosition="3" alphatest="on">
            <convert type="ServiceName2">Reference</convert>
        </widget>
            <ePixmap position="399,576" size="116,73" zPosition="1" transparent="1" alphatest="on" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/QuickSignal/icons_quick/picon_fon.png" />
        <widget source="session.CurrentService" path="piconProv" render="PiconUni"     position="407,583" size="100,60" zPosition="3" alphatest="on">
            <convert type="ServiceName2">Provider</convert>
        </widget>
            <ePixmap position="532,576" size="116,73" zPosition="1" transparent="1" alphatest="on" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/QuickSignal/icons_quick/picon_fon.png" />
        <widget source="session.CurrentService" path="piconSat" render="PiconUni"     position="540,583" size="100,60" zPosition="3" alphatest="on">
            <convert type="ServiceName2">OrbitalPos</convert>
        </widget>
          <ePixmap position="798,576" size="116,73" zPosition="1" transparent="1" alphatest="on" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/QuickSignal/icons_quick/picon_fon.png" />
        <widget source="session.CurrentService" path="piconCrypt" render="PiconUni"     position="673,583" size="100,60" zPosition="3" alphatest="on">
            <convert type="CaidInfo2">CryptInfo2</convert>
        </widget>
        
        <ePixmap position="665,576" size="116,73" zPosition="1" transparent="1" alphatest="on" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/QuickSignal/icons_quick/picon_fon.png" />
        <widget source="session.CurrentService" render="PiconUni" path="piconCam" position="806,583" size="100,60" alphatest="blend" zPosition="3">
           <convert type="EmuName">
           </convert>
        </widget>
        
        <!-- Test Connect 
        <eLabel name="satq" text="de1.satq 1" position="40,295" size="120,25" font="Regular;20" halign="left" foregroundColor="#007b68ee" transparent="1" />
        <ePixmap position="5,300" size="28,16" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/QuickSignal/icons_quick/ico_offline.png" zPosition="1" />
        <widget source="session.CurrentService" render="Pixmap" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/QuickSignal/icons_quick/ico_online.png" position="5,300" size="28,16" zPosition="2" >
            <convert type="TestConnection">de1.satq.tv:10000:10</convert>
            <convert type="ConditionalShowHide" />
        </widget>
        
        <eLabel name="satq" text="ua1.satq 2" position="40,320" size="120,25" font="Regular;20" halign="left" foregroundColor="#007b68ee" transparent="1" />
        <ePixmap position="5,325" size="28,16" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/QuickSignal/icons_quick/ico_offline.png" zPosition="1" />
        <widget source="session.CurrentService" render="Pixmap" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/QuickSignal/icons_quick/ico_online.png" position="5,325" size="28,16" zPosition="2" >
            <convert type="TestConnection">ua1.satq.tv:10000:10</convert>
            <convert type="ConditionalShowHide" />
        </widget>
        
        <eLabel name="satq" text="de2.satq 3" position="40,345" size="120,25" font="Regular;20" halign="left" foregroundColor="#007b68ee" transparent="1" />
        <ePixmap position="5,350" size="28,16" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/QuickSignal/icons_quick/ico_offline.png" zPosition="1" />
        <widget source="session.CurrentService" render="Pixmap" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/QuickSignal/icons_quick/ico_online.png" position="5,350" size="28,16" zPosition="2" >
            <convert type="TestConnection">de2.satq.tv:10000:10</convert>
            <convert type="ConditionalShowHide" />
        </widget>
        
        <eLabel name="satq" text="ua2.satq 7" position="40,370" size="120,25" font="Regular;20" halign="left" foregroundColor="#007b68ee" transparent="1" />
        <ePixmap position="5,375" size="28,16" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/QuickSignal/icons_quick/ico_offline.png" zPosition="1" />
        <widget source="session.CurrentService" render="Pixmap" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/QuickSignal/icons_quick/ico_online.png" position="5,375" size="28,16" zPosition="2" >
            <convert type="TestConnection">ua2.satq.tv:10000:10</convert>
            <convert type="ConditionalShowHide" />
        </widget>
        
        <eLabel name="satq" text="de3.satq 9" position="40,395" size="120,25" font="Regular;20" halign="left" foregroundColor="#AAAAAA" transparent="1" />
        <ePixmap position="5,400" size="28,16" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/QuickSignal/icons_quick/ico_offline.png" zPosition="1" />
        <widget source="session.CurrentService" render="Pixmap" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/QuickSignal/icons_quick/ico_online.png" position="5,400" size="28,16" zPosition="2" >
            <convert type="TestConnection">de3.satq.tv:10000:10</convert>
            <convert type="ConditionalShowHide" />
        </widget>
        
        <eLabel name="satq" text="servboom 1" position="40,420" size="120,25" font="Regular;20" halign="left" foregroundColor="#AAAAAA" transparent="1" />
        <ePixmap position="5,425" size="28,16" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/QuickSignal/icons_quick/ico_offline.png" zPosition="1" />
        <widget source="session.CurrentService" render="Pixmap" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/QuickSignal/icons_quick/ico_online.png" position="5,425" size="28,16" zPosition="2" >
            <convert type="TestConnection">servboom1.zapto.org:4000:10</convert>
            <convert type="ConditionalShowHide" />
        </widget>
        
        <eLabel name="satq" text="servboom 2" position="40,445" size="120,25" font="Regular;20" halign="left" foregroundColor="#AAAAAA" transparent="1" />
        <ePixmap position="5,450" size="28,16" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/QuickSignal/icons_quick/ico_offline.png" zPosition="1" />
        <widget source="session.CurrentService" render="Pixmap" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/QuickSignal/icons_quick/ico_online.png" position="5,450" size="28,16" zPosition="2" >
            <convert type="TestConnection">servboom2.zapto.org:4000:10</convert>
            <convert type="ConditionalShowHide" />
        </widget>
        
        <eLabel name="satq" text="servboom 3" position="40,470" size="120,25" font="Regular;20" halign="left" foregroundColor="#AAAAAA" transparent="1" />
        <ePixmap position="5,475" size="28,16" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/QuickSignal/icons_quick/ico_offline.png" zPosition="1" />
        <widget source="session.CurrentService" render="Pixmap" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/QuickSignal/icons_quick/ico_online.png" position="5,475" size="28,16" zPosition="2" >
            <convert type="TestConnection">servboom3.no-ip.org:4000:10</convert>
            <convert type="ConditionalShowHide" />
        </widget>
        
        <eLabel name="satq" text="servboom 6" position="40,495" size="120,25" font="Regular;20" halign="left" foregroundColor="#AAAAAA" transparent="1" />
        <ePixmap position="5,500" size="28,16" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/QuickSignal/icons_quick/ico_offline.png" zPosition="1" />
        <widget source="session.CurrentService" render="Pixmap" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/QuickSignal/icons_quick/ico_online.png" position="5,500" size="28,16" zPosition="2" >
            <convert type="TestConnection">servboom6.hopto.org:4000:10</convert>
            <convert type="ConditionalShowHide" />
        </widget>
        
        <eLabel name="satq" text="servboom 7" position="40,520" size="120,25" font="Regular;20" halign="left" foregroundColor="#AAAAAA" transparent="1" />
        <ePixmap position="5,525" size="28,16" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/QuickSignal/icons_quick/ico_offline.png" zPosition="1" />
        <widget source="session.CurrentService" render="Pixmap" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/QuickSignal/icons_quick/ico_online.png" position="5,525" size="28,16" zPosition="2" >
            <convert type="TestConnection">servboom7.hopto.org:4000:10</convert>
            <convert type="ConditionalShowHide" />
        </widget> -->
        
        
        <!-- Channel and Provider -->
                <widget source="session.CurrentService" render="Label"          position="10,620" size="253,28" font="Regular;28" backgroundColor="#000000" foregroundColor="#0009fcff" transparent="1">
            <convert type="QuickServName2">Name</convert>
        </widget>
        <widget source="session.CurrentService" render="Label"           position="918,620" size="253,28" font="Regular;28" halign="right" backgroundColor="#000000" foregroundColor="#0009fcff" transparent="1">
            <convert type="QuickServName2">Provider</convert>
        </widget>
        
        <!-- Tuner Info  -->  
        <widget source="session.CurrentService" render="Label"    position="134,18" size="364,30" font="Regular;28" halign="left" backgroundColor="#000000" foregroundColor="#0009fcff" transparent="1">
                       <convert type="QuickServName2">%F %p %Y %f %M %s</convert>
                </widget>
                <widget source="session.CurrentService" render="Label"    position="682,18" size="364,30" font="Regular;28" halign="right" backgroundColor="#000000" foregroundColor="#0009fcff" transparent="1">
                       <convert type="QuickServName2">%c %l %h %m %g %b %e %S</convert>
                </widget>
    </screen>"""


##############################################################################
class QuickSignalScreen(Screen):
    def __init__(self, session):
        Screen.__init__(self, session)
        self.skin = SKIN

class QuickSig():
    def __init__(self):
        self.dialog = None

    def gotSession(self, session):
        self.dialog = session.instantiateDialog(QuickSignalScreen)

pSignal = QuickSig()

def ShowHide():
   if config.plugins.QuickSignal.enabled.value:
       config.plugins.QuickSignal.enabled.value = False
       pSignal.dialog.show()
   else:
       config.plugins.QuickSignal.enabled.value = True
       pSignal.dialog.hide()

class QuickSignal(Screen):
    def __init__(self, session):
        Screen.__init__(self, session)
        self.session = session
        config.plugins.QuickSignal.enabled.value = True
        ShowHide()
        self["actions"] = ActionMap(["WizardActions"],
        {
            
            "home": self.hideclose,
            "ok": self.hideclose,
            "right": self.hideclose,
            "back": self.hideclose,
            "left": self.hideclose,
            "down": self.hideclose,
            "up": self.hideclose,
        }, -2)
    
    def hideclose(self):
        config.plugins.QuickSignal.enabled.value = False
        ShowHide() 
        self.close()
 
def main(session, **kwargs):
    session.open(QuickSignal)
    
def sessionstart(reason, **kwargs):
    if reason == 0:
        pSignal.gotSession(kwargs["session"])

def Plugins(**kwargs):
    list = [PluginDescriptor(name=_("QuickSignal for Hotkey"), description=_("quicksignal for hotkey extentions"), where = [PluginDescriptor.WHERE_EXTENSIONSMENU], fnc=main)]
    list.append(PluginDescriptor(where=[PluginDescriptor.WHERE_SESSIONSTART], fnc=sessionstart)) 
    return list 
