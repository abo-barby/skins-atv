# -*- coding: utf-8 -*-
# ArmyTouchSetup
from __future__ import absolute_import
from __future__ import print_function
from .__init__ import _
from enigma import eTimer
from Components.ActionMap import ActionMap
from Components.config import config, getConfigListEntry, ConfigSubsection, ConfigSelection, ConfigYesNo, NoSave, ConfigNothing
from Components.ConfigList import ConfigListScreen
from Components.Label import Label
from Components.MenuList import MenuList
from Components.Pixmap import Pixmap
from Components.Sources.List import List
from Components.Sources.StaticText import StaticText
from Plugins.Plugin import PluginDescriptor
from Screens.SkinSelector import SkinSelector
from Screens.InputBox import InputBox
from Screens.MessageBox import MessageBox
from Screens.Screen import Screen
from Screens.Standby import TryQuitMainloop
from Tools.Directories import *
from Tools.LoadPixmap import LoadPixmap
from Tools import Notifications
from Tools.Notifications import AddPopup
from os import listdir, remove, rename, system, path, symlink, chdir, makedirs, mkdir
import shutil

cur_skin = config.skin.primary_skin.value.replace('/skin.xml', '')

def Plugins(**kwargs):
    return [PluginDescriptor(name=_("ArmyTouchSetup"), description=_("Army_Touch_FHD Skin Control"), where = [PluginDescriptor.WHERE_PLUGINMENU],
    icon="plugin.png", fnc=main)]

def main(session, **kwargs):
    if config.skin.primary_skin.value == "Army_Touch_FHD/skin.xml":
        session.open(ArmyTouch_Config)
    else:
        AddPopup(_('Please activate the Army_Touch_FHD skin before launching the control plugin.'), type=MessageBox.TYPE_ERROR, timeout=10)
        return []

def isInteger(s):
    try:
        int(s)
        return True
    except ValueError:
        return False

class ArmyTouch_Config(Screen, ConfigListScreen):

    skin = """
            <screen name="ArmyTouch_Config" position="center,center" size="1280,720" title="ArmyTouchSetup" >
                    <widget source="Title" render="Label" position="70,47" size="950,43" font="Regular;35" transparent="1" />
                    <widget name="config" position="70,115" size="700,480" scrollbarMode="showOnDemand" scrollbarWidth="6" transparent="1" />
                    <widget name="Picture" position="808,342" size="400,225" alphatest="on" />
                    <eLabel position=" 55,675" size="290, 5" zPosition="-10" backgroundColor="red" />
                    <eLabel position="350,675" size="290, 5" zPosition="-10" backgroundColor="green" />
                    <eLabel position="645,675" size="290, 5" zPosition="-10" backgroundColor="yellow" />
                    <eLabel position="940,675" size="290, 5" zPosition="-10" backgroundColor="blue" />
                    <widget name="key_red" position="70,635" size="260,25" zPosition="1" font="Regular;20" halign="left" foregroundColor="foreground" transparent="1" />
                    <widget name="key_green" position="365,635" size="260,25" zPosition="1" font="Regular;20" halign="left" foregroundColor="foreground" transparent="1" />
                    <widget name="key_yellow" position="660,635" size="260,25" zPosition="1" font="Regular;20" halign="left" foregroundColor="foreground" transparent="1" />
                    <widget name="key_blue" position="955,635" size="260,25" zPosition="0" font="Regular;20" halign="left" foregroundColor="foreground" transparent="1" />
            </screen>
    """

    def __init__(self, session, args = 0):
        self.session = session
        self.skin_lines = []
        self.changed_screens = False
        Screen.__init__(self, session)

        self.start_skin = config.skin.primary_skin.value

        if self.start_skin != "skin.xml":
            self.getInitConfig()

        self.list = []
        ConfigListScreen.__init__(self, self.list, session = self.session, on_change = self.changedEntry)

        self["key_red"] = Label(_("Cancel"))
        self["key_green"] = Label(_("OK"))
        self["key_yellow"] = Label()
        self["key_blue"] = Label(_("About"))
        self["setupActions"] = ActionMap(["SetupActions", "ColorActions"],
                {
                        "green": self.keyGreen,
                        "red": self.cancel,
                        "yellow": self.keyYellow,
                        "blue": self.about,
                        "cancel": self.cancel,
                        "ok": self.keyOk,
                }, -2)

        self["Picture"] = Pixmap()

        if not self.selectionChanged in self["config"].onSelectionChanged:
            self["config"].onSelectionChanged.append(self.selectionChanged)

        if self.start_skin == "skin.xml":
            self.onLayoutFinish.append(self.openSkinSelectorDelayed)
        else:
            self.createConfigList()

    def getInitConfig(self):

        global cur_skin
        self.is_army = False
        if cur_skin == 'ArmySt':
            self.is_army = True

        self.title = _("ArmyTouch - Setup")
        self.skin_base_dir = "/usr/share/enigma2/%s/" % cur_skin


        self.default_font_file = "font_army_Regular.xml"
        self.default_style_file = "style_Original.xml"
        self.default_weather2_file = "weather2_Original.xml"

        self.default_color_file = "color_Original.xml"
        self.default_barinfo_file = "barinfo_Original.xml"
        self.default_progr_epg_file = "progr_epg_Original.xml"
        self.default_secbar_file = "secbar_Original.xml"
        self.default_ch_se_file = "ch_se_Original.xml"
        self.default_progr_secbar_file = "progr_secbar_Original.xml"
        self.default_emc_file = "emc_Original.xml"
        self.default_progr_infobar_file = "progr_infobar_Original.xml"
        self.default_weather_file = "weather_Original.xml"
        self.default_hands_file = "hands_Original.xml"
        self.default_buttons_file = "buttons_Original.xml"
        self.default_volume_file = "volume_Original.xml"
        self.default_movie_file = "movie_Original.xml"
        self.default_cpu_file = "cpu_Original.xml"
        self.default_display_file = "display_Original.xml"

        self.style_file = "skin_user_style.xml"
        self.weather2_file = "skin_user_weather2.xml"
        self.color_file = "skin_user_color.xml"
        self.barinfo_file = "skin_user_barinfo.xml"
        self.progr_epg_file = "skin_user_progr_epg.xml"
        self.secbar_file = "skin_user_secbar.xml"
        self.ch_se_file = "skin_user_ch_se.xml"
        self.progr_secbar_file = "skin_user_progr_secbar.xml"
        self.emc_file = "skin_user_emc.xml"
        self.progr_infobar_file = "skin_user_progr_infobar.xml"
        self.weather_file = "skin_user_weather.xml"
        self.hands_file = "skin_user_hands.xml"
        self.buttons_file = "skin_user_buttons.xml"
        self.volume_file = "skin_user_volume.xml"
        self.movie_file = "skin_user_movie.xml"
        self.cpu_file = "skin_user_cpu.xml"
        self.display_file = "skin_user_display.xml"

        # style
        current, choices = self.getSettings(self.default_style_file, self.style_file)
        self.myArmySt_style = NoSave(ConfigSelection(default=current, choices = choices))
        # weather2
        current, choices = self.getSettings(self.default_weather2_file, self.weather2_file)
        self.myArmySt_weather2 = NoSave(ConfigSelection(default=current, choices = choices))
        # color
        current, choices = self.getSettings(self.default_color_file, self.color_file)
        self.myArmySt_color = NoSave(ConfigSelection(default=current, choices = choices))
        # barinfo
        current, choices = self.getSettings(self.default_barinfo_file, self.barinfo_file)
        self.myArmySt_barinfo = NoSave(ConfigSelection(default=current, choices = choices))
        # progr_epg
        current, choices = self.getSettings(self.default_progr_epg_file, self.progr_epg_file)
        self.myArmySt_progr_epg = NoSave(ConfigSelection(default=current, choices = choices))
        # secbar
        current, choices = self.getSettings(self.default_secbar_file, self.secbar_file)
        self.myArmySt_secbar = NoSave(ConfigSelection(default=current, choices = choices))
        # ch_se
        current, choices = self.getSettings(self.default_ch_se_file, self.ch_se_file)
        self.myArmySt_ch_se = NoSave(ConfigSelection(default=current, choices = choices))
        # progr_secbar
        current, choices = self.getSettings(self.default_progr_secbar_file, self.progr_secbar_file)
        self.myArmySt_progr_secbar = NoSave(ConfigSelection(default=current, choices = choices))
        # emc 
        current, choices = self.getSettings(self.default_emc_file, self.emc_file)
        self.myArmySt_emc = NoSave(ConfigSelection(default=current, choices = choices))
        # progr_infobar
        current, choices = self.getSettings(self.default_progr_infobar_file, self.progr_infobar_file)
        self.myArmySt_progr_infobar = NoSave(ConfigSelection(default=current, choices = choices))
        # weather
        current, choices = self.getSettings(self.default_weather_file, self.weather_file)
        self.myArmySt_weather = NoSave(ConfigSelection(default=current, choices = choices))
        # hands
        current, choices = self.getSettings(self.default_hands_file, self.hands_file)
        self.myArmySt_hands = NoSave(ConfigSelection(default=current, choices = choices))
        # buttons
        current, choices = self.getSettings(self.default_buttons_file, self.buttons_file)
        self.myArmySt_buttons = NoSave(ConfigSelection(default=current, choices = choices))
        # volume
        current, choices = self.getSettings(self.default_volume_file, self.volume_file)
        self.myArmySt_volume = NoSave(ConfigSelection(default=current, choices = choices))
        # movie
        current, choices = self.getSettings(self.default_movie_file, self.movie_file)
        self.myArmySt_movie = NoSave(ConfigSelection(default=current, choices = choices))
        # cpu
        current, choices = self.getSettings(self.default_cpu_file, self.cpu_file)
        self.myArmySt_cpu = NoSave(ConfigSelection(default=current, choices = choices))
        # display
        current, choices = self.getSettings(self.default_display_file, self.display_file)
        self.myArmySt_display = NoSave(ConfigSelection(default=current, choices = choices))
        # myarmy
        myarmy_active = self.getmyAtileState()
        self.myArmySt_active = NoSave(ConfigYesNo(default=myarmy_active))
        self.myArmySt_fake_entry = NoSave(ConfigNothing())

    def getSettings(self, default_file, user_file):
        # default setting
        default = ("default", _("Default"))

        # search typ
        styp = default_file.replace('_Original.xml', '')
        if self.is_army:
            search_str = '%s_army_' %styp
        else:
            search_str = '%s_' %styp

        # possecbarle setting
        choices = []
        files = listdir(self.skin_base_dir)
        if path.exists(self.skin_base_dir + 'allScreens/%s/' %styp):
            files += listdir(self.skin_base_dir + 'allScreens/%s/' %styp)
        for f in sorted(files, key=str.lower):
            if f.endswith('.xml') and f.startswith(search_str):
                friendly_name = f.replace(search_str, "").replace(".xml", "").replace("_", " ")
                if path.exists(self.skin_base_dir + 'allScreens/%s/%s' %(styp, f)):
                    choices.append((self.skin_base_dir + 'allScreens/%s/%s' %(styp, f), friendly_name))
                else:
                    choices.append((self.skin_base_dir + f, friendly_name))
        choices.append(default)

        # current setting
        myfile = self.skin_base_dir + "mySkin_off/" + user_file
        current = ''
        if not path.exists(myfile):
            if path.exists(self.skin_base_dir + default_file):
                if path.islink(myfile):
                    remove(myfile)
                chdir(self.skin_base_dir)
                symlink(default_file, user_file)
            elif path.exists(self.skin_base_dir + 'allScreens/%s/%s' %(styp, default_file)):
                if path.islink(myfile):
                    remove(myfile)
                chdir(self.skin_base_dir)
                symlink(self.skin_base_dir + 'allScreens/%s/%s' %(styp, default_file), user_file)
            else:
                current = None
        if current is None:
            current = default
        else:
            filename = path.realpath(myfile)
            friendly_name = path.basename(filename).replace(search_str, "").replace(".xml", "").replace("_", " ")
            current = (filename, friendly_name)

        return current[0], choices

    def createConfigList(self):
        self.set_style = getConfigListEntry(_("Style:"), self.myArmySt_style)
        self.set_barinfo = getConfigListEntry(_("Infobar:"), self.myArmySt_barinfo)
        self.set_secbar = getConfigListEntry(_("Secondinfobar:"), self.myArmySt_secbar)
        self.set_buttons = getConfigListEntry(_("Buttons:"), self.myArmySt_buttons)		
        self.set_volume = getConfigListEntry(_("Volume:"), self.myArmySt_volume)
        self.set_movie = getConfigListEntry(_("Movieplayer_bar:"), self.myArmySt_movie)
        self.set_cpu = getConfigListEntry(_("Cpu_4core:"), self.myArmySt_cpu)
        self.set_display = getConfigListEntry(_("Display:"), self.myArmySt_display)
        self.set_color = getConfigListEntry(_("Interface font color:"), self.myArmySt_color)
        self.set_hands = getConfigListEntry(_("Clock_Hands_Infobar:"), self.myArmySt_hands)
        self.set_progr_infobar = getConfigListEntry(_("Progress_Infobar:"), self.myArmySt_progr_infobar)
        self.set_progr_secbar = getConfigListEntry(_("Progress_Secondinfobar:"), self.myArmySt_progr_secbar)
        self.set_ch_se = getConfigListEntry(_("Channelselection:"), self.myArmySt_ch_se)
        self.set_weather = getConfigListEntry(_("WeatherMSN_anim:"), self.myArmySt_weather)
        self.set_weather2 = getConfigListEntry(_("WeatherPlugin2_anim:"), self.myArmySt_weather2)
        self.set_progr_epg = getConfigListEntry(_("Progress_EPG_all:"), self.myArmySt_progr_epg)
        self.set_emc = getConfigListEntry(_("EMC_Selection:"), self.myArmySt_emc)
        self.set_myarmy = getConfigListEntry(_("Enable %s Extentions:") % cur_skin, self.myArmySt_active)
        self.set_new_skin = getConfigListEntry(_("Change skin"), ConfigNothing())
        self.list = []
        self.list.append(self.set_myarmy)
        if self.myArmySt_active.value:
            if len(self.myArmySt_color.choices)>1:
                self.list.append(self.set_color)
            if len(self.myArmySt_style.choices)>1:
                self.list.append(self.set_style)		
            if len(self.myArmySt_buttons.choices)>1:
                self.list.append(self.set_buttons)
            if len(self.myArmySt_volume.choices)>1:
                self.list.append(self.set_volume)								
            if len(self.myArmySt_barinfo.choices)>1:
                self.list.append(self.set_barinfo)				
            if len(self.myArmySt_secbar.choices)>1:
                self.list.append(self.set_secbar)				
            if len(self.myArmySt_movie.choices)>1:
                self.list.append(self.set_movie)
            if len(self.myArmySt_emc.choices)>1:   
                self.list.append(self.set_emc)				
            if len(self.myArmySt_display.choices)>1:
                self.list.append(self.set_display)
            if len(self.myArmySt_cpu.choices)>1:
                self.list.append(self.set_cpu)
            if len(self.myArmySt_weather.choices)>1:
                self.list.append(self.set_weather)
            if len(self.myArmySt_weather2.choices)>1:
                self.list.append(self.set_weather2)
            if len(self.myArmySt_hands.choices)>1:
                self.list.append(self.set_hands)
            if len(self.myArmySt_progr_infobar.choices)>1:
                self.list.append(self.set_progr_infobar)
            if len(self.myArmySt_progr_secbar.choices)>1:
                self.list.append(self.set_progr_secbar)
            if len(self.myArmySt_ch_se.choices)>1:
                self.list.append(self.set_ch_se)				
            if len(self.myArmySt_progr_epg.choices)>1:
                self.list.append(self.set_progr_epg)				

            self.list.append(self.set_new_skin)
        self["config"].list = self.list
        self["config"].l.setList(self.list)
        if self.myArmySt_active.value:
            self["key_yellow"].setText(_("Switch screen"))
        else:
            self["key_yellow"].setText("")

    def changedEntry(self):
        if self["config"].getCurrent() == self.set_style:
            self.setPicture(self.myArmySt_style.value)
        elif self["config"].getCurrent() == self.set_weather2:
            self.setPicture(self.myArmySt_weather2.value)
        elif self["config"].getCurrent() == self.set_color:
            self.setPicture(self.myArmySt_color.value)
        elif self["config"].getCurrent() == self.set_hands:
            self.setPicture(self.myArmySt_hands.value)
        elif self["config"].getCurrent() == self.set_barinfo:
            self.setPicture(self.myArmySt_barinfo.value)
        elif self["config"].getCurrent() == self.set_progr_epg:
            self.setPicture(self.myArmySt_progr_epg.value)
        elif self["config"].getCurrent() == self.set_secbar:
            self.setPicture(self.myArmySt_secbar.value)
        elif self["config"].getCurrent() == self.set_ch_se:
            self.setPicture(self.myArmySt_ch_se.value)
        elif self["config"].getCurrent() == self.set_progr_secbar:
            self.setPicture(self.myArmySt_progr_secbar.value)
        elif self["config"].getCurrent() == self.set_emc:
            self.setPicture(self.myArmySt_emc.value)
        elif self["config"].getCurrent() == self.set_progr_infobar:
            self.setPicture(self.myArmySt_progr_infobar.value)
        elif self["config"].getCurrent() == self.set_weather:
            self.setPicture(self.myArmySt_weather.value)
        elif self["config"].getCurrent() == self.set_buttons:
            self.setPicture(self.myArmySt_buttons.value)
        elif self["config"].getCurrent() == self.set_volume:
            self.setPicture(self.myArmySt_volume.value)
        elif self["config"].getCurrent() == self.set_movie:
            self.setPicture(self.myArmySt_movie.value)
        elif self["config"].getCurrent() == self.set_cpu:
            self.setPicture(self.myArmySt_cpu.value)
        elif self["config"].getCurrent() == self.set_display:
            self.setPicture(self.myArmySt_display.value)
        elif self["config"].getCurrent() == self.set_myarmy:
            if self.myArmySt_active.value:
                self["key_yellow"].setText(_("Switch screen"))
            else:
                self["key_yellow"].setText("")
            self.createConfigList()

    def selectionChanged(self):
        if self["config"].getCurrent() == self.set_style:
            self.setPicture(self.myArmySt_style.value)
        elif self["config"].getCurrent() == self.set_weather2:
            self.setPicture(self.myArmySt_weather2.value)
        elif self["config"].getCurrent() == self.set_color:
            self.setPicture(self.myArmySt_color.value)
        elif self["config"].getCurrent() == self.set_hands:
            self.setPicture(self.myArmySt_hands.value)
        elif self["config"].getCurrent() == self.set_barinfo:
            self.setPicture(self.myArmySt_barinfo.value)
        elif self["config"].getCurrent() == self.set_progr_epg:
            self.setPicture(self.myArmySt_progr_epg.value)
        elif self["config"].getCurrent() == self.set_secbar:
            self.setPicture(self.myArmySt_secbar.value)
        elif self["config"].getCurrent() == self.set_ch_se:
            self.setPicture(self.myArmySt_ch_se.value)
        elif self["config"].getCurrent() == self.set_progr_secbar:
            self.setPicture(self.myArmySt_progr_secbar.value)
        elif self["config"].getCurrent() == self.set_emc:
            self.setPicture(self.myArmySt_emc.value)
        elif self["config"].getCurrent() == self.set_progr_infobar:
            self.setPicture(self.myArmySt_progr_infobar.value)
        elif self["config"].getCurrent() == self.set_weather:
            self.setPicture(self.myArmySt_weather.value)
        elif self["config"].getCurrent() == self.set_buttons:
            self.setPicture(self.myArmySt_buttons.value)
        elif self["config"].getCurrent() == self.set_volume:
            self.setPicture(self.myArmySt_volume.value)
        elif self["config"].getCurrent() == self.set_movie:
            self.setPicture(self.myArmySt_movie.value)
        elif self["config"].getCurrent() == self.set_cpu:
            self.setPicture(self.myArmySt_cpu.value)
        elif self["config"].getCurrent() == self.set_display:
            self.setPicture(self.myArmySt_display.value)
        else:
            self["Picture"].hide()

    def cancel(self):
        if self["config"].isChanged():
            self.session.openWithCallback(self.cancelConfirm, MessageBox, _("Really close without saving settings?"), MessageBox.TYPE_YESNO, default = False)
        else:
            for x in self["config"].list:
                x[1].cancel()
            if self.changed_screens:
                self.restartGUI()
            else:
                self.close()

    def cancelConfirm(self, result):
        if result is None or result is False:
            print("[%s]: Cancel confirmed." % cur_skin)
        else:
            print("[%s]: Cancel confirmed. Config changes will be lost." % cur_skin)
            for x in self["config"].list:
                x[1].cancel()
            self.close()

    def getmyAtileState(self):
        chdir(self.skin_base_dir)
        if path.exists("mySkin"):
            return True
        else:
            return False

    def setPicture(self, f):
        pic = f.split('/')[-1].replace(".xml", ".png")
        preview = self.skin_base_dir + "preview/preview_" + pic
        if path.exists(preview):
            self["Picture"].instance.setPixmapFromFile(preview)
            self["Picture"].show()
        else:
            self["Picture"].hide()

    def keyYellow(self):
        if self.myArmySt_active.value:
            self.session.openWithCallback(self.ArmyTouchScreenCB, ArmyTouchScreens)
        else:
            self["config"].setCurrentIndex(0)

    def keyOk(self):
        sel =  self["config"].getCurrent()
        if sel is not None and sel == self.set_new_skin:
            self.openSkinSelector()
        else:
            self.keyGreen()

    def openSkinSelector(self):
        self.session.openWithCallback(self.skinChanged, SkinSelector)

    def openSkinSelectorDelayed(self):
        self.delaytimer = eTimer()
        self.delaytimer.callback.append(self.openSkinSelector)
        self.delaytimer.start(200, True)

    def skinChanged(self, ret = None):
        global cur_skin
        cur_skin = config.skin.primary_skin.value.replace('/skin.xml', '')
        if cur_skin == "skin.xml":
            self.restartGUI()
        else:
            self.getInitConfig()
            self.createConfigList()

    def keyGreen(self):
        if self["config"].isChanged():
            for x in self["config"].list:
                x[1].save()
            chdir(self.skin_base_dir)

            # style
            self.makeSettings(self.myArmySt_style, self.style_file)
            # weather2
            self.makeSettings(self.myArmySt_weather2, self.weather2_file)
            # color
            self.makeSettings(self.myArmySt_color, self.color_file)
            # hands
            self.makeSettings(self.myArmySt_hands, self.hands_file)
            # barinfo
            self.makeSettings(self.myArmySt_barinfo, self.barinfo_file)
            # progr_epg
            self.makeSettings(self.myArmySt_progr_epg, self.progr_epg_file)
            # secbar
            self.makeSettings(self.myArmySt_secbar, self.secbar_file)
            # ch_se
            self.makeSettings(self.myArmySt_ch_se, self.ch_se_file)
            # progr_secbar
            self.makeSettings(self.myArmySt_progr_secbar, self.progr_secbar_file)
            # emc
            self.makeSettings(self.myArmySt_emc, self.emc_file)
            # progr_infobar
            self.makeSettings(self.myArmySt_progr_infobar, self.progr_infobar_file)
            # weather
            self.makeSettings(self.myArmySt_weather, self.weather_file)
            # buttons
            self.makeSettings(self.myArmySt_buttons, self.buttons_file)
            # volume
            self.makeSettings(self.myArmySt_volume, self.volume_file)
            # movie
            self.makeSettings(self.myArmySt_movie, self.movie_file)
            # cpu
            self.makeSettings(self.myArmySt_cpu, self.cpu_file)
            # display
            self.makeSettings(self.myArmySt_display, self.display_file)

            if not path.exists("mySkin_off"):
                mkdir("mySkin_off")
                print("makedir mySkin_off")
            if self.myArmySt_active.value:
                if not path.exists("mySkin") and path.exists("mySkin_off"):
                    symlink("mySkin_off", "mySkin")
            else:
                if path.exists("mySkin"):
                    if path.exists("mySkin_off"):
                        if path.islink("mySkin"):
                            remove("mySkin")
                        else:
                            shutil.rmtree("mySkin")
                    else:
                        rename("mySkin", "mySkin_off")
            self.restartGUI()
        elif  config.skin.primary_skin.value != self.start_skin:
            self.restartGUI()
        else:
            if self.changed_screens:
                self.restartGUI()
            else:
                self.close()

    def makeSettings(self, config_entry, user_file):
        if path.exists("mySkin_off/" + user_file) or path.islink("mySkin_off/" + user_file):
            remove("mySkin_off/" + user_file)
        if config_entry.value != 'default':
            symlink(config_entry.value, "mySkin_off/" + user_file)

    def ArmyTouchScreenCB(self):
        self.changed_screens = True
        self["config"].setCurrentIndex(0)

    def restartGUI(self):
        restartbox = self.session.openWithCallback(self.restartGUIcb, MessageBox, _("Restart necessary, restart GUI now?"), MessageBox.TYPE_YESNO)
        restartbox.setTitle(_("Message"))

    def about(self):
        self.session.open(ArmyTouch_About)

    def restartGUIcb(self, answer):
        if answer is True:
            self.session.open(TryQuitMainloop, 3)
        else:
            self.close()

class ArmyTouch_About(Screen):

    def __init__(self, session, args = 0):
        self.session = session
        Screen.__init__(self, session)
        self["setupActions"] = ActionMap(["SetupActions", "ColorActions"],
                {
                        "cancel": self.cancel,
                        "ok": self.keyOk,
                }, -2)

    def keyOk(self):
        self.close()

    def cancel(self):
        self.close()

class ArmyTouchScreens(Screen):

    skin = """
            <screen name="ArmyTouchScreens" position="center,center" size="1280,720" title="ArmyTouchSetup">
                    <widget source="Title" render="Label" position="70,47" size="950,43" font="Regular;35" transparent="1" />
                    <widget source="menu" render="Listbox" position="70,115" size="700,480" scrollbarMode="showOnDemand" scrollbarWidth="6" scrollbarSliderBorderWidth="1" enableWrapAround="1" transparent="1">
                            <convert type="TemplatedMultiContent">
                                    {"template":
                                            [
                                                    MultiContentEntryPixmapAlphaTest(pos = (2, 2), size = (25, 24), png = 2),
                                                    MultiContentEntryText(pos = (35, 4), size = (500, 24), font=0, flags = RT_HALIGN_LEFT|RT_VALIGN_CENTER, text = 1),
                                            ],
                                            "fonts": [gFont("Regular", 22),gFont("Regular", 16)],
                                            "itemHeight": 30
                                    }
                            </convert>
                    </widget>
                    <widget name="Picture" position="808,342" size="400,225" alphatest="on" />
                    <eLabel position=" 55,675" size="290, 5" zPosition="-10" backgroundColor="red" />
                    <eLabel position="350,675" size="290, 5" zPosition="-10" backgroundColor="green" />
                    <widget source="key_red" render="Label" position="70,635" size="260,25" zPosition="1" font="Regular;20" halign="left" transparent="1" />
                    <widget source="key_green" render="Label" position="365,635" size="260,25" zPosition="1" font="Regular;20" halign="left" transparent="1" />
            </screen>
    """

    def __init__(self, session):
        Screen.__init__(self, session)
        self.session = session

        global cur_skin
        self.is_army = False
        if cur_skin == 'ArmyTouch':
            self.is_army = True

        self.title = _("%s additional screens") % cur_skin
        try:
            self["title"]=StaticText(self.title)
        except:
            print('self["title"] was not found in skin')

        self["key_red"] = StaticText(_("Exit"))
        self["key_green"] = StaticText(_("On"))

        self["Picture"] = Pixmap()

        menu_list = []
        self["menu"] = List(menu_list)

        self["shortcuts"] = ActionMap(["SetupActions", "ColorActions", "DirectionActions"],
        {
                "ok": self.runMenuEntry,
                "cancel": self.keyCancel,
                "red": self.keyCancel,
                "green": self.runMenuEntry,
        }, -2)

        self.skin_base_dir = "/usr/share/enigma2/%s/" % cur_skin
        self.screen_dir = "allScreens"
        self.skinparts_dir = "skinparts"
        self.file_dir = "mySkin_off"
        my_path = resolveFilename(SCOPE_SKIN, "%s/icons/lock_on.png" % cur_skin)
        if not path.exists(my_path):
            my_path = resolveFilename(SCOPE_SKIN, "skin_default/icons/lock_on.png")
        self.enabled_pic = LoadPixmap(cached = True, path = my_path)
        my_path = resolveFilename(SCOPE_SKIN, "%s/icons/lock_off.png" % cur_skin)
        if not path.exists(my_path):
            my_path = resolveFilename(SCOPE_SKIN, "skin_default/icons/lock_off.png")
        self.disabled_pic = LoadPixmap(cached = True, path = my_path)

        if not self.selectionChanged in self["menu"].onSelectionChanged:
            self["menu"].onSelectionChanged.append(self.selectionChanged)

        self.onLayoutFinish.append(self.createMenuList)

    def selectionChanged(self):
        sel = self["menu"].getCurrent()
        if sel is not None:
            self.setPicture(sel[0])
            if sel[2] == self.enabled_pic:
                self["key_green"].setText(_("Off"))
            elif sel[2] == self.disabled_pic:
                self["key_green"].setText(_("On"))

    def createMenuList(self):
        chdir(self.skin_base_dir)
        f_list = []
        dir_path = self.skin_base_dir + self.screen_dir
        if not path.exists(dir_path):
            makedirs(dir_path)
        dir_skinparts_path = self.skin_base_dir + self.skinparts_dir
        if not path.exists(dir_skinparts_path):
            makedirs(dir_skinparts_path)
        file_dir_path = self.skin_base_dir + self.file_dir
        if not path.exists(file_dir_path):
            makedirs(file_dir_path)
        dir_global_skinparts = resolveFilename(SCOPE_SKIN, "skinparts")
        if path.exists(dir_global_skinparts):
            for pack in listdir(dir_global_skinparts):
                if path.isdir(dir_global_skinparts + "/" + pack):
                    for f in listdir(dir_global_skinparts + "/" + pack):
                        if path.exists(dir_global_skinparts + "/" + pack + "/" + f + "/" + f + "_Atile.xml"):
                            if not path.exists(dir_path + "/skin_" + f + ".xml"):
                                symlink(dir_global_skinparts + "/" + pack + "/" + f + "/" + f + "_Atile.xml", dir_path + "/skin_" + f + ".xml")
                            if not path.exists(dir_skinparts_path + "/" + f):
                                symlink(dir_global_skinparts + "/" + pack + "/" + f, dir_skinparts_path + "/" + f)
        list_dir = sorted(listdir(dir_path), key=str.lower)
        for f in list_dir:
            if f.endswith('.xml') and f.startswith('skin_'):
                if (not path.islink(dir_path + "/" + f)) or os.path.exists(os.readlink(dir_path + "/" + f)):
                    friendly_name = f.replace("skin_", "")
                    friendly_name = friendly_name.replace(".xml", "")
                    friendly_name = friendly_name.replace("_", " ")
                    linked_file = file_dir_path + "/" + f
                    if path.exists(linked_file):
                        if path.islink(linked_file):
                            pic = self.enabled_pic
                        else:
                            remove(linked_file)
                            symlink(dir_path + "/" + f, file_dir_path + "/" + f)
                            pic = self.enabled_pic
                    else:
                        pic = self.disabled_pic
                    f_list.append((f, friendly_name, pic))
                else:
                    if path.islink(dir_path + "/" + f):
                        remove(dir_path + "/" + f)
        menu_list = [ ]
        for entry in f_list:
            menu_list.append((entry[0], entry[1], entry[2]))
        self["menu"].updateList(menu_list)
        self.selectionChanged()

    def setPicture(self, f):
        pic = f.replace(".xml", ".png")
        preview = self.skin_base_dir + "preview/preview_" + pic
        if path.exists(preview):
            self["Picture"].instance.setPixmapFromFile(preview)
            self["Picture"].show()
        else:
            self["Picture"].hide()

    def keyCancel(self):
        self.close()

    def runMenuEntry(self):
        sel = self["menu"].getCurrent()
        if sel is not None:
            if sel[2] == self.enabled_pic:
                remove(self.skin_base_dir + self.file_dir + "/" + sel[0])
            elif sel[2] == self.disabled_pic:
                symlink(self.skin_base_dir + self.screen_dir + "/" + sel[0], self.skin_base_dir + self.file_dir + "/" + sel[0])
            self.createMenuList()
