# by beber...03.2022,
# 03.2022 several enhancements : several renders
# for channel,
# <widget source="session.CurrentService" render="PosterXSingleEpgList" position="800,540" size="900,150" noWrap="1" font="Regular;32" foregroundColor="grey" />
# for epg, event
# <widget source="session.Event_Now" render="PosterXSingleEpgList" position="800,540" size="900,150" noWrap="1" font="Regular;32" foregroundColor="grey" />
# <widget source="Event" render="PosterXSingleEpgList" position="800,540" size="900,150" noWrap="1" font="Regular;32" foregroundColor="grey" />

from Components.VariableText import VariableText
from Components.Renderer.Renderer import Renderer
from enigma import eLabel, eEPGCache
from Components.Sources.ServiceEvent import ServiceEvent
from Components.Sources.CurrentService import CurrentService
from Components.Sources.EventInfo import EventInfo
from Components.Sources.Event import Event
import NavigationInstance
from time import localtime, mktime, time
from datetime import datetime
from Components.config import config

class Kitte888PosterXSingleEpgListPrime(Renderer, VariableText):

	def __init__(self):
		Renderer.__init__(self)
		VariableText.__init__(self)
		self.epgcache = eEPGCache.getInstance()

	GUI_WIDGET = eLabel

	def changed(self, what):
		evt = None
		text = ""
		try:
			if isinstance(self.source, ServiceEvent):
				service = self.source.getCurrentService()
			elif isinstance(self.source, CurrentService):
				service = self.source.getCurrentServiceRef()
			elif isinstance(self.source, EventInfo):
				service = NavigationInstance.instance.getCurrentlyPlayingServiceReference()
			elif isinstance(self.source, Event):
				service = NavigationInstance.instance.getCurrentlyPlayingServiceReference()
			evt = self.epgcache.lookupEvent(['IBDCT', (service.toString(), 0, -1, -1)])
		except:
			self.text = "xx:xx No data\nxx:xx No data\nxx:xx No data\nxx:xx No data\n"
			return

		if evt:
			now = localtime(time())
			try:
				hour, minute = config.epgselection.graph_primetimehour.value, config.epgselection.graph_primetimemins.value
			except:
				hour, minute = 20, 15
			dt = datetime(now.tm_year, now.tm_mon, now.tm_mday, hour, minute)
			primetime = int(mktime(dt.timetuple()))
			next = False
			for x in evt:
				if x[4]:
					begin = x[1]
					end = x[1]+x[2]
					if begin <= primetime and end > primetime or next:
						if not next and end <= primetime + 1200: # 20 mins tolerance to starting next event
							next = True
							continue
						t = localtime(begin)
						text = text + "%02d:%02d %s\n" % (t[3], t[4], x[4])
						break
					if begin > primetime: # entry > primetime ? -> primetime not in epg
						text = text + "n/a"
						break
				else:
					text = text + "n/a"
					break

		self.text = text