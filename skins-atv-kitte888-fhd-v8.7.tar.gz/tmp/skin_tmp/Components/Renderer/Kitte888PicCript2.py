#!/usr/bin/python
# -*- coding: utf-8 -*-
from __future__ import print_function
from Components.Pixmap import Pixmap
from Components.Renderer.Renderer import Renderer
from enigma import iServiceInformation
from enigma import ePixmap
from Tools.Directories import fileExists, SCOPE_CURRENT_SKIN,resolveFilename
from Components.Element import cached
from Components.Converter.Poll import Poll
import os
ablauf = " 1234 "
#open("/tmp/PicCript2", "w").write(ablauf)

class Kitte888PicCript2(Renderer):

    __module__ = __name__
    if fileExists('/usr/lib64'):
        searchPaths = (
            '/data/%s/',
            '/usr/lib64/enigma2/python/Plugins/Extensions/%s/',
            '/media/sde1/%s/',
            '/media/cf/%s/',
            '/media/sdd1/%s/',
            '/media/hdd/%s/',
            '/media/usb/%s/',
            '/media/ba/%s/',
            '/mnt/ba/%s/',
            '/media/sda/%s/',
            '/etc/%s/',
            '/usr/share/enigma2/%s/',
            )
    else:
        searchPaths = (
            '/data/%s/',
            '/usr/lib/enigma2/python/Plugins/Extensions/%s/',
            '/media/sde1/%s/',
            '/media/cf/%s/',
            '/media/sdd1/%s/',
            '/media/hdd/%s/',
            '/media/usb/%s/',
            '/media/ba/%s/',
            '/mnt/ba/%s/',
            '/media/sda/%s/',
            '/etc/%s/',
            '/usr/share/enigma2/%s/',
            )

    def __init__(self):
        Renderer.__init__(self)
        self.path = 'cript'
        self.nameCache = { }
        self.pngname = ' '
        self.picon_default = 'picon_default.png'

    def applySkin(self, desktop, parent):
        attribs = [ ]
        #open("/tmp/PicEmuattribs", "w").write(attribs)
        for (attrib, value) in self.skinAttributes:
            if attrib == 'path':
                self.path = value
            elif attrib == 'picon_default':
                self.picon_default = value
            else:
                attribs.append((attrib, value))
        self.skinAttributes = attribs
        return Renderer.applySkin(self, desktop, parent)

    GUI_WIDGET = ePixmap

    def changed(self, what):
        if self.instance:
            pngname = ' '
            if what[0] is not self.CHANGED_CLEAR:
                sname = 'none'
                #open("/tmp/PicCriptsname", "w").write(sname)
                service = self.source.service
                if service:
                    info = service and service.info()
                    if info:
                        caids = \
                            info.getInfoObject(iServiceInformation.sCAIDs)
                        if caids:
                            if len(caids) > 0:
                                for caid in caids:
                                    caid = self.int2hex(caid)
                                    if len(caid) is 3:
                                        caid = '0%s' % caid
                                        caid = caid[:2]
                                        caid = caid.upper()
                                        if caid == '26':
                                            sname = 'BiSS'
                                        elif caid == '01':
                                            sname = 'SEC'
                                        elif caid == '06':
                                            sname = 'IRD'
                                        elif caid == '17':
                                            sname = 'BET'
                                        elif caid == '05':
                                            sname = 'VIA'
                                        elif caid == '18':
                                            sname = 'NAG'
                                        elif caid == '09':
                                            sname = 'NDS'
                                        elif caid == '0B':
                                            sname = 'CONN'
                                        elif caid == '0D':
                                            sname = 'CRW'
                                        elif caid == '4A':
                                            sname = 'DRE'
                                        elif caid == '0E':
                                            sname = 'PowerVU'
                                        elif caid == '22':
                                            sname = 'Codicrypt'
                                        elif caid == '07':
                                            sname = 'DigiCipher'
                                        elif caid == 'A1':
                                            sname = 'Rosscrypt'
                                        elif caid == '56':
                                            sname = 'Verimatrix'

                pngname = self.nameCache.get(sname, '')
                if pngname is '':
                    pngname = self.findPicon(sname)
                    if pngname is not '':
                        self.nameCache[sname] = pngname
            if pngname is '':
                pngname = self.nameCache.get('default', '')
                if pngname is '':
                    pngname = self.findPicon('picon_default')
                    if pngname is '':
                        tmp = resolveFilename(SCOPE_CURRENT_SKIN,
                                'picon_default.png')
                        if fileExists(tmp):
                            pngname = tmp
                        self.nameCache['default'] = pngname

            if self.pngname is not pngname:
                self.pngname = pngname
                self.instance.setPixmapFromFile(self.pngname)

    def int2hex(self, int):
        return '%x' % int

    def findPicon(self, serviceName):
        for path in self.searchPaths:
            pngname = path % self.path + serviceName + '.png'
            #open("/tmp/PicCriptPath", "w").write(path)
            #open("/tmp/PicCriptPngname", "w").write(pngname)
            if fileExists(pngname):
                return pngname
        return ''