# -*- coding: utf-8 -*-
# by digiteng...06.2020, 12.2020
# <widget source="session.Event_Now" render="poster" position="0,0" size="185,278" zPosition="1" />
from Renderer import Renderer
from enigma import ePixmap, eTimer, loadJPG, ePicLoad
from Components.AVSwitch import AVSwitch
from Components.Pixmap import Pixmap
from Components.config import config
import json
import re
import os
import socket

try:
	from urllib.request import urlopen, quote
except:
	from urllib2 import urlopen, quote
	
tmdb_api = "04e706c432d1afa5543759dfe69ca421"

if not os.path.isdir("/tmp/poster"):
	os.makedirs("/tmp/poster")
	path_folder = "/tmp/poster/"
else:
	path_folder = "/tmp/poster/"
	
try:
	folder_size=sum([sum(map(lambda fname: os.path.getsize(os.path.join(path_folder, fname)), files)) for path_folder, folders, files in os.walk(path_folder)])
	posters_sz = "%0.f" % (folder_size/(1024*1024.0))
	if posters_sz >= "100":    # folder remove size(100MB)...
		import shutil
		shutil.rmtree(path_folder)
except:
	pass
	
class nitrofhdPoster(Renderer):
	def __init__(self):
		Renderer.__init__(self)
		self.pstrNm = ''
		self.evntNm = ''
		self.intCheck()
		
	def intCheck(self):
		try:
			socket.setdefaulttimeout(2)
			socket.socket(socket.AF_INET, socket.SOCK_STREAM).connect(("8.8.8.8", 53))
			return True
		except:
			return False
			
	GUI_WIDGET = ePixmap
	def changed(self, what):
		try:
			if not self.instance:
				return
			if what[0] == self.CHANGED_CLEAR:
				self.instance.hide()
			if what[0] != self.CHANGED_CLEAR:
				self.delay()
		except:
			pass
			
	def showPoster(self):
		self.event = self.source.event
		if self.event:
			title = self.event.getEventName()
			title = re.sub("([\(\[]).*?([\)\]])|(: odc.\d+)|(\d+: odc.\d+)|(\d+ odc.\d+)|(:)|( -(.*?).*)|(,)|!", "", title)
			title = title.replace("Die ", "The ").replace("Das ", "The ").replace("und ", "and ").replace("LOS ", "The ").rstrip()
			try:
				if pathLoc:
					if os.path.exists("{}xtraEvent/poster/{}.jpg".format(pathLoc, title)):
						path_folder = "{}xtraEvent/poster/".format(pathLoc)
					else:
						path_folder = "/tmp/poster/"
				else:
					path_folder = "/tmp/poster/"
			except:
				path_folder = "/tmp/poster/"
			pstrNm = "{}{}.jpg".format(path_folder, title)
			if os.path.exists(pstrNm):
				self.instance.setPixmap(loadJPG(pstrNm))
				self.instance.show()
			else:
				self.downloadPoster(title)
				self.instance.hide()
		else:
			self.instance.hide()
			return
			
	def downloadPoster(self, title):
		sd = ""
		sd = self.event.getShortDescription() + "\n" + self.event.getExtendedDescription()
		w = [
			"serial", 
			"series", 
			"serie", 
			"serien", 
			"séries", 
			"serious", 
			"folge", 
			"episodio", 
			"episode", 
			"ep.", 
			"staffel", 
			"soap", 
			"doku", 
			"tv", 
			"talk", 
			"show", 
			"news", 
			"factual", 
			"entertainment", 
			"telenovela", 
			"dokumentation", 
			"dokutainment", 
			"documentary", 
			"informercial", 
			"information", 
			"sitcom", 
			"reality", 
			"program", 
			"magazine", 
			"mittagsmagazin"
			]
		for i in w:
			if i in sd.lower():
				srch = "tv"
				break
			else:
				srch = "multi"				
		try:
			if self.intCheck():
				url_tmdb = "https://api.themoviedb.org/3/search/{}?api_key={}&query={}".format(srch, tmdb_api, quote(title))
				poster = json.load(urlopen(url_tmdb))['results'][0]['poster_path']
				if poster:
					url_poster = "https://image.tmdb.org/t/p/w185{}".format(poster)
					dwn_poster = path_folder + "{}.jpg".format(title)
					with open(dwn_poster,'wb') as f:
						f.write(urlopen(url_poster).read())
			else:
				return
		except:
			return
			
	def delay(self):
		self.timer = eTimer()
		self.timer.callback.append(self.showPoster)
		self.timer.start(100, True)
		