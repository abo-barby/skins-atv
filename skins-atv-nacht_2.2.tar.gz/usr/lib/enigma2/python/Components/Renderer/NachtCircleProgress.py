# by digiteng...11.2020
# <widget render="NachtCircleProgress" source="global.CurrentTime" mode="scan" position="1500,140" size="150,150" backgroundColor="black" zPosition="3" transparent="1" />
from Renderer import Renderer
from enigma import eTimer, ePoint, eWidget, eLabel, eSize, gFont, eDVBVolumecontrol
from skin import parseColor
import os

class NachtCircleProgress(Renderer):
	def __init__(self):
		Renderer.__init__(self)

		self.vol_timer = eTimer()
		self.vol_timer.callback.append(self.pollme)

	GUI_WIDGET = eWidget
	def applySkin(self, desktop, screen):
		attribs = self.skinAttributes[:]
		for attrib, value in self.skinAttributes:
			if attrib == 'position':
				self.px = int(value.split(',')[0])
				self.py = int(value.split(',')[1])
			elif attrib == 'size':
				self.szX = int(value.split(',')[0])
				self.szY = int(value.split(',')[1])
			elif attrib == 'backgroundColor':
				self.backgroundColor = value
			elif attrib == 'mode':
				self.mode = value
		self.skinAttributes = attribs
		ret = Renderer.applySkin(self, desktop, screen)
		
	def changed(self, what):
		
		if not self.suspended:
			val = 0
			try:
				if self.mode == "event":
					val = self.source.text
				elif self.mode == "service":
					val = self.source.value / 100
				elif self.mode == "volume":
					val = eDVBVolumecontrol.getInstance().getVolume()
				elif self.mode == "scan":
					if os.path.exists("/tmp/sc"):
						with open("/tmp/sc", "r") as f:
							val = f.readlines()[0]
				elif self.mode == "ipk_slider":
					if os.path.exists("/tmp/rlst"):
						with open("/tmp/rlst", "r") as f:
							rv = f.readlines()[0]
					if os.path.exists("/tmp/ilst"):
						with open("/tmp/ilst", "r") as f:
							iv = f.readlines()[0]
					val = 100 / int(iv)
					val = val * int(rv)
				elif self.mode == "ipk_aslider":
					if os.path.exists("/tmp/asldr"):
						with open("/tmp/asldr", "r") as f:
							val = f.readlines()[0]

				val = int(val)
				if val:
					x, y = 0, 0
					if val >= 0 and val <= 50:
						x = 0
						y += (-val*2)*(float(self.szY)/100)
						y = int(y)
						
						p = (self.szY/2-self.szY/4)+(self.szY/20+6)
						s = (self.szY/4)+(self.szY/10)
						f = (self.szY/4)

						self.prgrsText.setText(str(val))
						self.prgrsText.setBackgroundColor(parseColor(self.backgroundColor))
						self.prgrsText.resize(eSize(self.szX, int(s)))
						self.prgrsText.move(ePoint(0, int(p)))
						self.prgrsText.setFont(gFont("Console", int(f)))
						self.prgrsText.setHAlign(eLabel.alignCenter)
						self.prgrsText.setTransparent(1)
						self.prgrsText.setZPosition(99)
						self.prgrsText.show()
						
						self.prgrsVal.setBackgroundColor(parseColor(self.backgroundColor))
						self.prgrsVal.resize(eSize(self.szX/2, self.szY))
						self.prgrsVal.move(ePoint(x, y))
						self.prgrsVal.setTransparent(0)
						self.prgrsVal.setZPosition(3)
						self.prgrsVal.show()
						
						self.prgrsValR.setBackgroundColor(parseColor(self.backgroundColor))
						self.prgrsValR.resize(eSize(self.szX/2, self.szY))
						self.prgrsValR.move(ePoint(self.szX/2, 0))
						self.prgrsValR.setTransparent(0)
						self.prgrsValR.setZPosition(3)
						self.prgrsValR.show()
					elif val >= 51 and val <= 100:
						x = self.szX/2
						y -= -((val-50)*2)*(float(self.szY)/100)
						y = int(y)

						p = (self.szY/2-self.szY/4)+(self.szY/20+6)
						s = (self.szY/4)+(self.szY/10)
						f = (self.szY/4)

						self.prgrsText.setText(str(val))
						self.prgrsText.setBackgroundColor(parseColor(self.backgroundColor))
						self.prgrsText.resize(eSize(self.szX, int(s)))
						self.prgrsText.move(ePoint(0, int(p)))
						self.prgrsText.setFont(gFont("Console", int(f)))
						self.prgrsText.setHAlign(eLabel.alignCenter)
						self.prgrsText.setTransparent(1)
						self.prgrsText.setZPosition(99)
						self.prgrsText.show()
						
						self.prgrsValR.clearBackgroundColor()
						self.prgrsValR.hide()
						self.prgrsVal.clearBackgroundColor()
						self.prgrsVal.setBackgroundColor(parseColor(self.backgroundColor))
						self.prgrsVal.resize(eSize(x, self.szY))
						self.prgrsVal.move(ePoint(x, y))
						self.prgrsVal.setTransparent(0)
						self.prgrsVal.setZPosition(3)
						self.prgrsVal.show()
					else:
						return
				else:
					self.prgrsText.hide()
					self.prgrsVal.hide()
					self.prgrsVal.resize(eSize(self.szX, self.szY))
					self.prgrsVal.move(ePoint(0,0))
					self.prgrsVal.setTransparent(0)
					self.prgrsVal.setZPosition(3)
					self.prgrsVal.show()
			except:
				pass
				
	def GUIcreate(self, parent):
		self.instance = eWidget(parent)
		self.prgrsVal = eLabel(self.instance)
		self.prgrsValR = eLabel(self.instance)
		self.prgrsText = eLabel(self.instance)
		
	def pollme(self):
		self.changed(None)
		return
		
	def onShow(self):
		self.suspended = False
		self.vol_timer.start(200)
		
	def onHide(self):
		self.suspended = True
		self.vol_timer.stop()
		